package protect.securec.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import protect.securec.R;
import protect.securec.encryption;
import protect.securec.log.LOG;


public class MyAdapter extends RecyclerView.Adapter<VH> {

    List<ApkItem> data;
    Context context;

    public MyAdapter(List<ApkItem> data, Context context) {
        this.data = data;
        this.context = context;
    }

    public MyAdapter(List<ApkItem> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        ApkItem apkItem = data.get(position);
        holder.tv.setText(apkItem.name);
        holder.bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //LOG.v(view, apkItem.getPath());
                encryption.Encryption(apkItem.getPath(),context);
                LOG.v(view,"加固完毕！路径："+encryption.DOWNLOAD_PATH);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


}
