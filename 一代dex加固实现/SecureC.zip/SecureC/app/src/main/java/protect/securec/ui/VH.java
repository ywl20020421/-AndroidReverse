package protect.securec.ui;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import protect.securec.R;

public class VH extends RecyclerView.ViewHolder {
    TextView tv;
    Button bt;

    public VH(@NonNull View itemView) {
        super(itemView);
        tv = itemView.findViewById(R.id.textView);
        bt = itemView.findViewById(R.id.button);
    }
}
