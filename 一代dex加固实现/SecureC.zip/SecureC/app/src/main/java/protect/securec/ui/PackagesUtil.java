package protect.securec.ui;

import android.Manifest;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

import protect.securec.log.LOG;

public class PackagesUtil {
    // 获取已经安装的所有应用, PackageInfo　系统类，包含应用信息
    // 在Activity中请求权限
    public static boolean isSystemApp(ApplicationInfo pi) {
        boolean isSysApp = (pi.flags & ApplicationInfo.FLAG_SYSTEM) == 1;
        boolean isSysUpd = (pi.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 1;
        return isSysApp || isSysUpd;
    }
    public static List<ApkItem> getPackages(Context context) {
        List<ApkItem> list=new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // 在安卓11或以上版本
            List<PackageInfo> packages = context.getPackageManager().getInstalledPackages(PackageManager.GET_ACTIVITIES |
                    PackageManager.GET_SERVICES);
            PackageManager packageManager =context.getPackageManager();

            // 获取所有已安装应用程序的包信息
            //List<ApplicationInfo> packages = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

            // 遍历包信息列表并输出应用名称
            for (PackageInfo packageInfo : packages) {
                if(!isSystemApp(packageInfo.applicationInfo)){
                    String appName = packageManager.getApplicationLabel(packageInfo.applicationInfo).toString();
                    String sourceDir = packageInfo.applicationInfo.sourceDir;
                    ApkItem appInfo = new ApkItem();
                    appInfo.setName(appName);
                    appInfo.setPath(sourceDir);
//                appInfo.setAppIcon(packageInfo.applicationInfo.loadIcon(context.getPackageManager()));//获取应用图标
                    //LOG.d(appInfo.toString());
                    list.add(appInfo);
                    //LOG.d("App Name"+appName);
                }

            }
        } else {
            // 在安卓11以下版本
            List<PackageInfo> packages = context.getPackageManager().getInstalledPackages(PackageManager.GET_PERMISSIONS);//.getInstalledPackages(PackageManager.GET_PERMISSIONS);
           // LOG.d("size "+packages.size());
            for (int i = 0; i < packages.size(); i++) {
                PackageInfo packageInfo = packages.get(i);
                if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) { //非系统应用

                    String mName = packageInfo.applicationInfo.loadLabel(context.getPackageManager()).toString();//获取应用名称
                    String sourceDir = packageInfo.applicationInfo.sourceDir;//获取路径
                    // AppInfo 自定义类，包含应用信息
                    ApkItem appInfo = new ApkItem();
                    appInfo.setName(mName);
                    appInfo.setPath(sourceDir);
//                appInfo.setAppIcon(packageInfo.applicationInfo.loadIcon(context.getPackageManager()));//获取应用图标
                    //LOG.d(appInfo.toString());
                    list.add(appInfo);
//            } else { // 系统应用
//
                }
            }
        }



        return list;
    }
}
