package protect.securec;

import static cn.wjdiankong.main.Main.mainx;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import protect.securec.log.LOG;

public class encryption {
   static String path;

    public static final String DOWNLOAD_PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath() +File.separator+"jiaGuApk"+File.separator+"encryption.apk";
    static String target;
    static String jiaGu;
    static Context context;

    public static void Encryption(String p,Context c){
        path=p;
        context=c;


        //注入加固代码
        Inject_reinforcement_code();

        //修改配置文件
        Modify_configuration_file();
        //打包程序
        packaged_applications();
        //删除jiaGu
        FileUtils.DeleteFolder(jiaGu);
        //输出加固程序
        out_apk();


    }
    public static void out_apk(){
        File file_target = new File(target);
        File out = new File(DOWNLOAD_PATH);
        LOG.d("开始创建文件夹！");
        LOG.d("file_target："+file_target.getAbsolutePath());
        try {
            File file = new File(out.getParent());
            if(!file.exists()){
                file.mkdirs();
            }
            out.createNewFile();
            FileInputStream fileInputStream = new FileInputStream(file_target);
            FileOutputStream fileOutputStream = new FileOutputStream(out);
            int len=0;
            byte[] buffer = new byte[1024];

            while((len=fileInputStream.read(buffer))!=-1){
                fileOutputStream.write(buffer,0,len);
            }

            fileInputStream.close();
            fileOutputStream.close();

            //删除备用
            file_target.delete();

        }catch (Exception e){
            LOG.d("输出加固程序失败！"+e);
        }
        LOG.d("输出文件路径:"+out.getAbsolutePath());

    }

    //打包
    private static void packaged_applications() {
        LOG.d("zip: 压缩目录："+jiaGu);
        File fileToCompress = new File(jiaGu);

        // 创建输出ZIP文件
        //这里要修改文件路径
        File zipFile = new File(jiaGu);
        zipFile=new File(zipFile.getParent()+File.separator+"encrypted.apk");
        target=zipFile.getAbsolutePath();

        LOG.d( "zip: 压缩文件："+zipFile.getAbsolutePath());

        try {
            UnzipUtil.compressFileOrFolder(fileToCompress.getAbsolutePath()+File.separator,zipFile.getAbsolutePath());
        } catch (Exception e) {
            LOG.d("zip: 压缩失败"+e);
            throw new RuntimeException(e);
        }
    }

     //修改配置文件
    private static void Modify_configuration_file() {
        String[] arg={"-attr","-m","application", "package" ,"name" ,"protect.securec.Protect", jiaGu+File.separator+"AndroidManifest.xml", jiaGu+File.separator+"AndroidManifest.xml"};
        mainx(arg);
        LOG.d( "修改配置文件: 完成xml修改");
    }

    //解压注入
    private static void Inject_reinforcement_code() {
        File source = new File(path);
        File aarget=context.getDir("apk", Context.MODE_PRIVATE);
        aarget=new File(aarget,"jiaGu");
        jiaGu=aarget.getAbsolutePath();
        UnzipUtil.decompressFile(aarget.getAbsolutePath(),source.getAbsolutePath());
        File[] files = aarget.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                return file.getName().endsWith(".dex");
            }
        });
        //File[] DexFiles = jiami(files);
        int a=0;
        for (File file : files) {
            if(file.getName().startsWith("encryption")){
                break;
            }
            File target = new File(file.getParent() + File.separator + "encryption" + file.getName().substring(0,file.getName().length()-3)+"ywl");
            try {
                InputStream inputStream = new FileInputStream(file);
                FileOutputStream fileOutputStream = new FileOutputStream(target);
                int len=0;
                byte[] buffer=new byte[1024];
                while((len=inputStream.read(buffer))!=-1){
                    for (int i = 0; i < len; i++) {
                        buffer[i]^=i;
                    }
                    fileOutputStream.write(buffer,0,len);
                }
                inputStream.close();
                fileOutputStream.close();
                //DexFiles[a]=target;
                a++;
                file.delete();
                //Log.d(TAG, "deProtect: 加密完成");
            }catch (Exception e){
                LOG.d("deProtect: ERROR"+e);
            }

        }

        //开始注入
        File file = new File(jiaGu + File.separator + "classes.dex");
        AssetManager assets = context.getAssets();
        try {
            InputStream open = assets.open("classes.dex");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            int len=0;
            byte[] buffer = new byte[1024];

            while((len=open.read(buffer))!=-1){
                fileOutputStream.write(buffer,0,len);
            }
            open.close();
            fileOutputStream.close();
            LOG.d("注入壳代码完成！文件路径："+file.getAbsolutePath());


        }catch (Exception e){
            LOG.d("壳代码注入错误: "+e);
        }

    }
}
