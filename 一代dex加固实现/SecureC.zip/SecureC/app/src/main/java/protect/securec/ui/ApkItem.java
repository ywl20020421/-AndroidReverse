package protect.securec.ui;

public class ApkItem {
    String name;
    String path;

    public ApkItem(String name, String path) {
        this.name = name;
        this.path = path;
    }

    public ApkItem() {
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "ApkItem{" +
                "name='" + name + '\'' +
                ", path='" + path + '\'' +
                '}';
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
