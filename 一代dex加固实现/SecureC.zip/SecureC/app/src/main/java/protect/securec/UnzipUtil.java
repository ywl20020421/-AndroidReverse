package protect.securec;

import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.CheckedInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class UnzipUtil {
    //过滤在mac上压缩时自动生成的__MACOSX文件夹
    private static final String MAC_IGNORE = "__MACOSX/";
    static String TAG="calvin!!";

    //解压
    public static void decompressFile(String target, String source) {
        if(TextUtils.isEmpty(target)){
            return;
        }
        try {
            File file = new File(source);
            if(!file.exists()) {
                return;
            }
            ZipFile zipFile = new ZipFile(file);
            ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(file));
            ZipEntry zipEntry = null;
            while ((zipEntry = zipInputStream.getNextEntry()) != null) {
                String fileName = zipEntry.getName();
                if(fileName != null && fileName.contains(MAC_IGNORE)) {
                    continue;
                }
                File temp = new File(target + File.separator + fileName);
                if(temp.getAbsolutePath().equals(target)){
                    continue;
                }
                //Log.d(TAG, "decompressFile: "+temp.getAbsolutePath());
                if(zipEntry.isDirectory()) {
                    File dir = new File(target + File.separator + fileName);
                    dir.mkdirs();
                    continue;
                }
                if (temp.getParentFile() != null && !temp.getParentFile().exists()) {
                    temp.getParentFile().mkdirs();
                }
                byte[] buffer = new byte[1024];
                OutputStream os = new FileOutputStream(temp);
                // 通过ZipFile的getInputStream方法拿到具体的ZipEntry的输入流
                InputStream is = zipFile.getInputStream(zipEntry);
                int len = 0;
                while ((len = is.read(buffer)) != -1) {
                    os.write(buffer, 0, len);
                }
                os.close();
                is.close();
            }
            zipInputStream.close();
        } catch (Exception e) {
            Log.d(TAG, "decompressFile: "+e);
            e.printStackTrace();
        }
    }

    //压缩
    public static void compressFileOrFolder(String sourcePath, String zipFilePath) {
        try {
            FileOutputStream fos = new FileOutputStream(zipFilePath);
            ZipOutputStream zipOut = new ZipOutputStream(fos);
            zipOut.setLevel(0);
            File fileToCompress = new File(sourcePath);
            compressFileOrFolderRecursive( fileToCompress, fileToCompress.getName(), zipOut);
            zipOut.close();
        } catch (Exception e) {
            Log.e(TAG, "Error compressing file/folder: " + e.getMessage());
        }
    }
    /**
     * 转换成文件信息实体
     * @param files 文件数组
     * @return
     */
    private static List<FileMessage> toFileMessages(File[] files) {
        List<FileMessage> messages = new ArrayList<FileMessage>(files.length);
        for (File file : files) {
            if(file.isFile()){
                FileMessage message = toFileMessage(file);
                if(null != message){
                    messages.add(message);
                }
            }
        }
        return messages;
    }

    /**
     * 转换成文件信息实体
     * @param file 文件
     * @return
     */
    private static FileMessage toFileMessage(File file) {
        try(FileInputStream fis = new FileInputStream(file);
            CheckedInputStream cis = new CheckedInputStream(fis, new CRC32());){
            byte[] buffer = new byte[fis.available()];
            cis.read(buffer);
            return new FileMessage(file.getName(), file.length(), buffer, cis.getChecksum().getValue());
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        return null;
    }

    static class FileMessage {
        // 文件名称
        private String name;
        // 文件长度
        private long length;
        private long crc;
        // 文件字节数组
        private byte[] buffer;

        public FileMessage(String name, long length, byte[] buffer, long crc){
            this.name = name;
            this.length = length;
            this.buffer = buffer;
            this.crc = crc;
        }

        public FileMessage() {
        }

        public long getCrc() {
            return crc;
        }

        public void setCrc(long crc){
            this.crc = crc;
        }

        public byte[] getBuffer() {
            return buffer;
        }

        public void setBuffer(byte[] buffer){
            this.buffer = buffer;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public long getLength() {
            return length;
        }

        public void setLength(long length){
            this.length = length;
        }
    }

    private static void compressFileOrFolderRecursive( File file, String parentPath, ZipOutputStream zipOut) throws Exception {
        if (file.isFile()) {
            FileInputStream fis = new FileInputStream(file);
            //Log.d(TAG, "parentPath :"+parentPath);
            parentPath=removeFirstCharacters(parentPath);
            ZipEntry zipEntry = new ZipEntry(parentPath);
            FileMessage message = toFileMessage(file);
            zipEntry.setMethod(ZipEntry.STORED);
            zipEntry.setSize(message.getLength());
            zipEntry.setCrc(message.getCrc());
            zipOut.putNextEntry(zipEntry);
            zipOut.write(message.getBuffer());
            fis.close();
        } else if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File nestedFile : files) {
                compressFileOrFolderRecursive( nestedFile, parentPath + File.separator + nestedFile.getName(), zipOut);
            }
        }
    }
    private static String removeFirstCharacters(String str) {
        for (int i = 0; i < str.toCharArray().length; i++) {
            if(str.toCharArray()[i]=='/'){
                return str.substring(i+1);
            }
        }
        return str;
    }

}
