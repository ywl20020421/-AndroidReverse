package protect.securec;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import dalvik.system.DexClassLoader;
import dalvik.system.PathClassLoader;
import protect.securec.log.LOG;

public class Protect extends Application {
    Context context;
    List<File> dex_s=new ArrayList<>();
    String path;
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        context=base;
        init();
    }
    @Override
    public void onCreate() {
        super.onCreate();
    }
    private void init() {
        //检测环境完毕
        LOG.d("开始检测环境");
        cheak();
        //解压
        LOG.d("开始解压");
        unzip();
        //解密
        LOG.d("开始解密");
        decrypt();
        //加载class
        LOG.d("加载dex");
        loadDex();
    }

    //解密dex
    private void decrypt() {
        List<File> dexS=new ArrayList<>();
        for (File file : dex_s) {
            if(file.getName().startsWith("decrypt")){
                break;
            }
            File target = new File(file.getParent() + File.separator + "decrypt" + file.getName().substring(0,file.getName().length()-3)+"dex");
            try {
                InputStream inputStream = new FileInputStream(file);
                FileOutputStream fileOutputStream = new FileOutputStream(target);
                int len=0;
                byte[] buffer=new byte[1024];
                while((len=inputStream.read(buffer))!=-1){
                    for (int i = 0; i < len; i++) {
                        buffer[i]^=i;
                    }
                    fileOutputStream.write(buffer,0,len);
                }
                inputStream.close();
                fileOutputStream.close();
                dexS.add(target);
                dex_s=dexS;
                file.delete();
                LOG.d("deProtect: 解密完成");
            }catch (Exception e){
                LOG.d("deProtect: ERROR"+e);
            }




        }
    }

    //加载dex
    private void loadDex() {
        if(dex_s.size()>0){
            ClassLoader classLoader = context.getClassLoader();
            Class<? extends ClassLoader> aClass = classLoader.getClass();
            try {
                // 本程序的dexElements 等会把咱们加载的 放进去
                Object pathList = getField(aClass, "pathList").get(classLoader);
                Object[] dexElements = (Object[])getField(pathList.getClass(), "dexElements").get(pathList);

                int lenNewDexElementsList=dexElements.length;
                List<Object[]> newDexElementsList=new ArrayList<>();
                newDexElementsList.add(dexElements);

                for (File dexFile : dex_s) {

                    File odex = getDir("odex", Context.MODE_PRIVATE);

                    DexClassLoader dexClassLoader = new DexClassLoader(dexFile.getAbsolutePath(), odex.getAbsolutePath(), null, (PathClassLoader) classLoader);

                    Object newPathList = getField(aClass, "pathList").get(dexClassLoader);
                    Object[] newDexElements = (Object[])getField(pathList.getClass(), "dexElements").get(newPathList);

                    lenNewDexElementsList+=newDexElements.length;
                    newDexElementsList.add(newDexElements);
                }

                Class<?> elementClazz = dexElements.getClass().getComponentType();
                Object newDexElements = Array.newInstance(elementClazz, lenNewDexElementsList);

                int copiedLen = 0;
                for (Object[] objects : newDexElementsList) {
                    LOG.d("ReplaceClassLoader: "+objects);
                    System.arraycopy(objects, 0, newDexElements, copiedLen, objects.length);
                    copiedLen += objects.length;
                }

                getField(pathList.getClass(), "dexElements").set(pathList,newDexElements);

            }catch (Exception e){
                LOG.d("ReplaceClassLoader: ERROR"+e);
            }


        }

    }

    //解压
    private void unzip() {
        File source=new File(getApplicationInfo().sourceDir);       //源包
        File target=getDir("apk", Context.MODE_PRIVATE);        //解压路径
        target=new File(target,"jiaGu");
        UnzipUtil.decompressFile(target.getAbsolutePath(),source.getAbsolutePath()); //开始解压
        File[] files = target.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                return file.getName().endsWith(".ywl");
            }
        });
        for (File file : files) {
            dex_s.add(file);
        }
        if(files.length>0){
            path=files[0].getPath();
        }

    }

    //检测环境
    private void cheak() {
        if(Check.checkRootPathSU()&&Check.isBeingDebugged()&&Check.isEmulator(context)){
            Check.over();
        }
    }



    private static Field getField(Class clazz, String fieldName) {
        Field field;
        while (clazz != null) {
            try {
                field = clazz.getDeclaredField(fieldName);
                field.setAccessible(true);
                return field;
            } catch (NoSuchFieldException e) {
                clazz = clazz.getSuperclass();
            }
        }
        return null;
    }
}
