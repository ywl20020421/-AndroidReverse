package protect.securec.log;

import android.util.Log;
import android.view.View;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

public class LOG {
    final static Boolean isOpen=true;
    final static String TAG="calvin!!";
    public static void d(String message){
        if(isOpen){
            Log.d(TAG, message);
        }
    }

    public static void v(View view,String msg){
        Snackbar.make(view,msg, BaseTransientBottomBar.LENGTH_LONG).show();
    }
}
