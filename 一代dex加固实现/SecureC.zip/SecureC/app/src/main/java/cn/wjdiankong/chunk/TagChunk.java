package cn.wjdiankong.chunk;

public class TagChunk {
	
	public StartTagChunk startTagChunk;
	public EndTagChunk endTagChunk;

}
