package cn.wjdiankong.chunk;

public interface Chunk {
	
	byte[] getChunkByte();

}
