#include <stdio.h>
#include <elf.h>
FILE * in;
//FILE *out;

void SoEncryption();
void En32So();
void En64So();
int main()
{
//    char path[1024]={0};
//    printf("����Ҫ���ܵ�so�ļ�·����\n");
//    scanf("%s",path);
    char *path = "D:\\android project\\sosec\\app\\build\\outputs\\apk\\debug\\libsosec.so";
    in=fopen(path,"r+b");
    if(in!=NULL){
        printf("\n�ļ��򿪳ɹ�������\n");
        //char section[1024];
//        printf("����Ҫ���ܵ�section: \n");
//        scanf("%s",section);
        SoEncryption();
    }
    return 0;
}

void SoEncryption(){
    char type;
    fseek(in,4,0);
    fread(&type,1,1,in);
    fseek(in,0,0);
    printf("%d",type);
    switch (type) {
    case 1:
        printf("\n32 SO ! \n");
        En32So();
    break;
    case 2:
        printf("\n64 SO ! \n");
        En64So();
        break;

    }
}
void  En64So(){
    //    char sectionName[1024]={0};
    //    printf("����Ҫ���ܵ�section: \n");
    //    scanf("%s",sectionName);
        char *sectionName=".encryption";
        printf("begin 64 so ....\n");
        Elf64_Ehdr  header;
        fread(&header,sizeof(Elf64_Ehdr),1,in);
     //   header.e_shnum;
     //   header.e_shoff;

        //�����ַ���
        Elf64_Shdr * sections=(Elf64_Shdr *) malloc(sizeof(Elf64_Shdr) * (int)header.e_shnum);
        fseek(in,header.e_shoff,0);
        fread(sections,sizeof(Elf64_Shdr),header.e_shnum,in);


        char *strings = malloc(sections[header.e_shnum-1].sh_size);
        fseek(in,sections[header.e_shnum-1].sh_offset,0);
        fread(strings,1,sections[header.e_shnum-1].sh_size,in);

        for(int i=0;i<header.e_shnum;i++){
            if(strcmp(sectionName,strings+sections[i].sh_name)==0){
                Elf64_Shdr * sections2= &sections[i];
                long long size2=  sections[i].sh_size;
                int size=size2;

                printf("�ҵ�Ŀ�꣺ %s  ƫ�ƣ�%x  ��С��%d \n",sectionName,(long)sections[i].sh_offset,size);

                printf("%d",size);
                char buffer[4096]={0};

                fseek(in,sections[i].sh_offset,0);
                fread(buffer,1,sections[i].sh_size,in);

                for(int a=0;a<size;a++){
                    buffer[a]= (char)buffer[a] ^ (char)78;
                }

                fseek(in,sections[i].sh_offset,0);
                if(fwrite(buffer,sizeof(char),size,in)==size){
                    fflush(in);
                    printf("���ܳɹ�������\n");
                }

            }
        }

        fclose(in);

}
void  En32So(){
//    char sectionName[1024]={0};
//    printf("����Ҫ���ܵ�section: \n");
//    scanf("%s",sectionName);
    char *sectionName=".encryption";
    printf("begin 32 so ....\n");
    Elf32_Ehdr  header;
    fread(&header,sizeof(Elf32_Ehdr),1,in);
 //   header.e_shnum;
 //   header.e_shoff;

    //�����ַ���
    Elf32_Shdr * sections=(Elf32_Shdr *) malloc(sizeof(Elf32_Shdr) * (int)header.e_shnum);
    fseek(in,header.e_shoff,0);
    fread(sections,sizeof(Elf32_Shdr),header.e_shnum,in);


    char *strings = malloc(sections[header.e_shnum-1].sh_size);
    fseek(in,sections[header.e_shnum-1].sh_offset,0);
    fread(strings,1,sections[header.e_shnum-1].sh_size,in);

    for(int i=0;i<header.e_shnum;i++){
        if(strcmp(sectionName,strings+sections[i].sh_name)==0){
            printf("�ҵ�Ŀ�꣺ %s  ƫ�ƣ�%x  ��С��%d \n",sectionName,sections[i].sh_offset,sections[i].sh_size);
            char *buffer=malloc(sections[i].sh_size);

            fseek(in,sections[i].sh_offset,0);
            fread(buffer,1,sections[i].sh_size,in);

            for(int a=0;a<sections[i].sh_size;a++){
                buffer[a]=buffer[a]^78;
            }

            fseek(in,sections[i].sh_offset,0);
            if(fwrite(buffer,1,sections[i].sh_size,in)>0){
                fflush(in);
                printf("���ܳɹ�������\n");
            }

        }
    }

    fclose(in);

}
