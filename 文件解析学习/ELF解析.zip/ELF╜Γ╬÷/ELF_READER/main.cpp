#include <elf.h>

void showProgram(fstream &file);
void showDynsym(fstream &file);
void showHeader(Elf32_Ehdr &head);
void showSHT(Elf32_Shdr shs[],char *str_tab);
static Elf32_Ehdr head;

int main()
{
     char filename[100];
    cout<<"����ELF�ļ�·����\n";
    cin>>filename;
    fstream file;
    file.open(filename,ios::in|ios::binary);

    if(!file.is_open()){
        cout<<"��ʧ�ܣ�\n";
    }else{
        cout<<"�򿪳ɹ�!\n";
        file.read((char *)&head,sizeof (head));


        //cout<<head.e_ident;
        file.seekg(head.e_shoff,ios::beg);
        Elf32_Shdr shs[head.e_shnum];
        //cout<<"\n******************************\n";
        file.read((char *)&shs,sizeof(shs));
        head.e_shstrndx; //shstr �ڱ����±�
        shs[head.e_shstrndx].sh_offset;//�ַ���ַ
        char *str_tab=new char[shs[head.e_shstrndx].sh_size];
        file.seekg(shs[head.e_shstrndx].sh_offset,ios::beg);
        file.read(str_tab,shs[head.e_shstrndx].sh_size);
        //�����ַ�����
        //1.�ҵ�֧������
        char *dynstr=NULL;
        for(int i=0;i<head.e_shnum;i++){
            if(strcmp(&str_tab[shs[i].sh_name],".dynstr")==0){
                //cout<<"ok!";
                dynstr=new char[shs[i].sh_size];
                //cout<<shs[i].sh_size;
                file.seekg(shs[i].sh_offset,ios::beg);
                //cout<<"��ַ��"<<shs[i].sh_offset<<"��С��"<<shs[i].sh_size<<endl;
                file.read(dynstr,shs[i].sh_size);
            }
        }
        Elf32_sym *symtab=NULL;
        int symtab_size=0;
        for(int i=0;i<head.e_shnum;i++){
            if(strcmp(&str_tab[shs[i].sh_name],".dynsym")==0){
               // cout<<"�ҵ���dynsm\n";
               symtab=new Elf32_sym[shs[i].sh_size/sizeof(Elf32_sym)];
              // cout<<"��С��"<<shs[i].sh_size/sizeof(Elf32_sym)<<endl;
               symtab_size=shs[i].sh_size/sizeof(Elf32_sym);
               file.seekg(shs[i].sh_offset,ios::beg);
               //cout<<"λ�ã�"<<shs[i].sh_offset<<endl;
               file.read((char *)symtab,shs[i].sh_size);
            }
        }
        //showSHT(shs,str_tab);

        //showProgram(file);
        //showProgram(file);

       while(1){

           int d;
           cout<<"����1��ʾͷ�ļ�\n����2��ʾ�ڱ�\n����3��ʾ�ض�λ���ű�\n����4��ʾ��ʾ�����\n";
           scanf("%d",&d);
            system("cls");
           switch (d) {
           case 1 :
                showHeader(head);
               break;
           case 2 :
               showSHT(shs,str_tab);
               break;
           case 3 :
               showDynsym(file);
               break;
           case 4 :
               showProgram(file);
               break;
           default:
               exit(1);
               break;
           }
       }





        }











//        printf("%-8s\t%-6s\t%-6s\t%-6s\t\n","Value","Info","Shndx","Name");
//                for(int i=0;i<symtab_size;i++){
//                    printf("(%d)%.6X\t",i,symtab[i].st_value);
//                    printf("%.6X\t",symtab[i].st_info);
//                    printf("%.6X\t",symtab[i].st_shndx);
//                    printf("%s\n",&dynstr[symtab[i].st_name]);
//                }
        //showDynsym(file);
        //        showHeader(head);


    return 0;
}


void showProgram(fstream &file){
    //file.read((char *)&head,sizeof (head));


    //cout<<head.e_ident;
    file.seekg(head.e_shoff,ios::beg);
    Elf32_Shdr shs[head.e_shnum];


    //cout<<"\n******************************\n";
    file.read((char *)&shs,sizeof(shs));
    head.e_shstrndx; //shstr �ڱ����±�
    shs[head.e_shstrndx].sh_offset;//�ַ���ַ
    char *str_tab=new char[shs[head.e_shstrndx].sh_size];
    file.seekg(shs[head.e_shstrndx].sh_offset,ios::beg);
    file.read(str_tab,shs[head.e_shstrndx].sh_size);




    //�����ַ�����
    //1.�ҵ�֧������
    char *dynstr=NULL;
    for(int i=0;i<head.e_shnum;i++){
        if(strcmp(&str_tab[shs[i].sh_name],".dynstr")==0){
            //cout<<"ok!";
            dynstr=new char[shs[i].sh_size];
            //cout<<shs[i].sh_size;
            file.seekg(shs[i].sh_offset,ios::beg);
            //cout<<"��ַ��"<<shs[i].sh_offset<<"��С��"<<shs[i].sh_size<<endl;
            file.read(dynstr,shs[i].sh_size);
        }
    }
    Elf32_sym *symtab=NULL;
    int symtab_size=0;
    for(int i=0;i<head.e_shnum;i++){
        if(strcmp(&str_tab[shs[i].sh_name],".dynsym")==0){
           // cout<<"�ҵ���dynsm\n";
           symtab=new Elf32_sym[shs[i].sh_size/sizeof(Elf32_sym)];
          // cout<<"��С��"<<shs[i].sh_size/sizeof(Elf32_sym)<<endl;
           symtab_size=shs[i].sh_size/sizeof(Elf32_sym);
           file.seekg(shs[i].sh_offset,ios::beg);
           //cout<<"λ�ã�"<<shs[i].sh_offset<<endl;
           file.read((char *)symtab,shs[i].sh_size);
        }
    }


    //����program��
    Elf32_phdr pproheader[head.e_phnum];
    cout<<"nums:"<<head.e_phentsize<<endl;
    file.seekg(head.e_phoff,ios::beg);

    file.read((char *)&pproheader,head.e_phnum*head.e_phentsize);

    for(int i=0;i<head.e_phnum;i++){
        switch(pproheader[i].p_type)
               {
                   case PT_NULL:
                       printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "", pproheader[i].p_offset, pproheader[i].p_vaddr,
                              pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
                   case PT_LOAD:
                       printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "LOAD", pproheader[i].p_offset, pproheader[i].p_vaddr,
                              pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
                   case PT_DYNAMIC:
                       printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "DYNAMIC", pproheader[i].p_offset, pproheader[i].p_vaddr,
                              pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
                   case PT_INTERP:
                       printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "INTERP", pproheader[i].p_offset, pproheader[i].p_vaddr,
                              pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
                   case PT_NOTE:
                       printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "NOTE", pproheader[i].p_offset, pproheader[i].p_vaddr,
                              pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
                   case PT_SHLIB:
                       printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "SHLIB", pproheader[i].p_offset, pproheader[i].p_vaddr,
                              pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
                                default:
                       break;
               }

        switch(pproheader[i].p_flags)
                {
                    case PF_X:
                        printf("%-6s  %-lX\r\n", "  E", pproheader[i].p_align);break;
                    case PF_W:
                        printf("%-6s  %-lX\r\n", " W ", pproheader[i].p_align);break;
                    case PF_R:
                        printf("%-6s  %-lX\r\n", "R  ", pproheader[i].p_align);break;
                    case PF_X|PF_W:
                        printf("%-6s  %-lX\r\n", " WE", pproheader[i].p_align);break;
                    case PF_X|PF_R:
                        printf("%-6s  %-lX\r\n", "R E", pproheader[i].p_align);break;
                    case PF_W|PF_R:
                        printf("%-6s  %-lX\r\n", "RW ", pproheader[i].p_align);break;
                    case PF_X|PF_R|PF_W:
                        printf("%-6s  %-lX\r\n", "RWE", pproheader[i].p_align);break;
                    default:printf("\r\n");

                        break;
                }


            }
}

void showDynsym(fstream &file){
    file.seekg(head.e_shoff,ios::beg);
    Elf32_Shdr shs[head.e_shnum];
    file.read((char *)&shs,sizeof(shs));
    //head.e_shstrndx; //shstr �ڱ����±�
    //shs[head.e_shstrndx].sh_offset;//�ַ���ַ
    char *str_tab=new char[shs[head.e_shstrndx].sh_size];
    file.seekg(shs[head.e_shstrndx].sh_offset,ios::beg);
    file.read(str_tab,shs[head.e_shstrndx].sh_size);


//        showHeader(head);
//        showSHT(shs,str_tab);

    //�����ַ�����
    //1.�ҵ�֧������
    char *dynstr=NULL;
    for(int i=0;i<head.e_shnum;i++){
        if(strcmp(&str_tab[shs[i].sh_name],".dynstr")==0){
            //cout<<"ok!";
            dynstr=new char[shs[i].sh_size];
            cout<<shs[i].sh_size;
            file.seekg(shs[i].sh_offset,ios::beg);
            cout<<"��ַ��"<<shs[i].sh_offset<<"��С��"<<shs[i].sh_size<<endl;
            file.read(dynstr,shs[i].sh_size);
        }
    }
    Elf32_sym *symtab=NULL;
    int symtab_size=0;
    for(int i=0;i<head.e_shnum;i++){
        if(strcmp(&str_tab[shs[i].sh_name],".dynsym")==0){
          //  cout<<"�ҵ���dynsm\n";
           symtab=new Elf32_sym[shs[i].sh_size/sizeof(Elf32_sym)];
         //  cout<<"��С��"<<shs[i].sh_size/sizeof(Elf32_sym)<<endl;
           symtab_size=shs[i].sh_size/sizeof(Elf32_sym);
           file.seekg(shs[i].sh_offset,ios::beg);
         //  cout<<"λ�ã�"<<shs[i].sh_offset<<endl;
           file.read((char *)symtab,shs[i].sh_size);
        }
    }

    printf("%-8s\t%-6s\t%-6s\t%-6s\t\n","Value","Info","Shndx","Name");
            for(int i=0;i<symtab_size;i++){
                printf("(%d)%.6X\t",i,symtab[i].st_value);
                printf("%.6X\t",symtab[i].st_info);
                printf("%.6X\t",symtab[i].st_shndx);
                printf("%s\n",&dynstr[symtab[i].st_name]);
            }

}

void showSHT(Elf32_Shdr shs[],char *str_tab){
    printf("%-16s \t %-8s\t %-8s\t %-8s\t %-8s\t %-8s\n" ,"����","����","��С","�ļ�ƫ��","���뷽ʽ","FLAG");

    for(int i=0;i<head.e_shnum;i++){
        printf("(%d)%-16s \t",i,&str_tab[shs[i].sh_name]);

        printf("%-8X \t",shs[i].sh_type);
          printf("%-8d(byte) \t",shs[i].sh_size);
        printf("0x%-8X \t",shs[i].sh_offset);
        printf("%-8X�ֽ� \t",shs[i].sh_addralign);
        printf("%-8X \t\n",shs[i].sh_flags);

    }
}





/*
 * ��ӡ��ʾELFͷ����Ϣ
 * */
void showHeader(Elf32_Ehdr &head){
    cout<<"ELF Header:\n";

    printf("\r\n");
    cout<<"Magic:\t\t";//��ӡħ��
    for(int i=0;i<16;i++){
        printf("%02X", head.e_ident[i]);
        putchar(' ');
    }

    printf("-----����ָ��---->%.4s",head.e_ident);

    printf("\r\n");
    printf("%s:\t\t", "Class"); //�ж��ļ�����
    switch(head.e_type)
      {
            case 0:
              printf("Invalid class\r\n");
              break;
            case 1:
              printf("ELF32\r\n");
              break;
            case 2:
              printf("ELF64\r\n");
              break;
            case 3:
                printf(".SO��̬���ļ�");
        break;
            case 4:
        printf(" core�ļ�");
        break;
          default:
              printf(" ERROR\r\n");
              break;
      }

    printf("\r\n");
    printf("Machine:\t");               //�������ܹ�
    switch (head.e_machine) {
        case 0:
        printf("No machine");
        break;
        case 1:
        printf("AT&T WE 32100");
        break;
        case 2:
        printf("SPARC");
        break;
        case 3:
        printf("Intel 80386");
        break;
        case 4:
        printf("Motorola 68000");
        break;
        case 5:
        printf("Motorola 88000");
        break;
    default:
        printf("��������ʶ�����");

    }

    printf("\r\n");
    printf("Version:\t");               //��ʾ�汾
    printf("Ŀǰ�İ汾��Ϊ:%d",head.e_version);

    printf("\r\n");
    printf("Entry:\t\t");                 //ִ�����
    printf("ִ�����Ϊ��0x%X",head.e_entry);

//    printf("\r\n");
//    printf("e_shoff:\t");                 //ִ�����
//    printf("����ͷ����ƫ�ƣ�0x%X",head.e_shoff);

    printf("\r\n");
    printf("Phoff:\t\t");                 //����ͷ����ƫ��
    printf("����ͷ����ƫ�ƣ�0x%X",head.e_phoff);
    printf("\r\n");

    printf("Shoff:\t\t");                 //
    printf("��ͷ���ļ�ƫ�ƣ�0x%X",head.e_shoff);
    printf("\r\n");

    printf("Flags:\t\t");                 //�ض��ڴ������ı�־
    printf("�ض��ڴ������ı�־��%d",head.e_flags);
    printf("\r\n");

    printf("Ehsize:\t\t");                 //ELF header�Ĵ�С
    printf("ELF header�Ĵ�С��0x%X",head.e_phoff);


    printf("\r\n");
    printf("Phentsize:\t");                 //program header tableִ�����
    printf("program header table��ÿ����ڵĴ�С��0x%X",head.e_phentsize);

    printf("\r\n");
    printf("Phoff:\t\t");                 //ELF header�Ĵ�С
    printf("Program Header Offset��0x%X",head.e_phoff);

    printf("\r\n");
    printf("Phentsize:\t");                 //program header table��ÿ����ڵĴ�С��
    printf("����ͷ�����ĵ�������Ĵ�С:0x%X",head.e_phentsize);

    printf("\r\n");
    printf("Phnum:\t\t");                 //����ļ�û��program header table, e_phnum��ֵΪ0��e_phentsize����e_phnum�͵õ�������program header table�Ĵ�С
    printf("����ͷ�����ı�����:0x%X",head.e_phnum);

    printf("\r\n");
    printf("Shentsize:\t");                 //section header table��entry�Ĵ�С
    printf("�������ĵ�������Ĵ�С:0x%X",head.e_shentsize);

    printf("\r\n");
    printf("Shnum:\t\t");                 //section header table��header����Ŀ
    printf("�������ı�����:0x%X",head.e_shnum);

    printf("\r\n");
    printf("Shstrndx:\t");                 //section header string table index
    printf("�ַ�����������ͷ:0x%X",head.e_shstrndx);

}



//        //����program��
//        Elf32_phdr pproheader[head.e_phnum];
//        cout<<"nums:"<<head.e_phentsize<<endl;
//        file.seekg(head.e_phoff,ios::beg);

//        file.read((char *)&pproheader,head.e_phnum*head.e_phentsize);

//        for(int i=0;i<head.e_phnum;i++){
//            switch(pproheader[i].p_type)
//                   {
//                       case PT_NULL:
//                           printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "", pproheader[i].p_offset, pproheader[i].p_vaddr,
//                                  pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
//                       case PT_LOAD:
//                           printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "LOAD", pproheader[i].p_offset, pproheader[i].p_vaddr,
//                                  pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
//                       case PT_DYNAMIC:
//                           printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "DYNAMIC", pproheader[i].p_offset, pproheader[i].p_vaddr,
//                                  pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
//                       case PT_INTERP:
//                           printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "INTERP", pproheader[i].p_offset, pproheader[i].p_vaddr,
//                                  pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
//                       case PT_NOTE:
//                           printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "NOTE", pproheader[i].p_offset, pproheader[i].p_vaddr,
//                                  pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
//                       case PT_SHLIB:
//                           printf("  %-14s  %016lX  %016lX  %016lX\r\n  %-14s  %016lX  %016lX  ", "SHLIB", pproheader[i].p_offset, pproheader[i].p_vaddr,
//                                  pproheader[i].p_paddr, "", pproheader[i].p_filesz, pproheader[i].p_memsz);break;
//                                    default:
//                           break;
//                   }

//            switch(pproheader[i].p_flags)
//                    {
//                        case PF_X:
//                            printf("%-6s  %-lX\r\n", "  E", pproheader[i].p_align);break;
//                        case PF_W:
//                            printf("%-6s  %-lX\r\n", " W ", pproheader[i].p_align);break;
//                        case PF_R:
//                            printf("%-6s  %-lX\r\n", "R  ", pproheader[i].p_align);break;
//                        case PF_X|PF_W:
//                            printf("%-6s  %-lX\r\n", " WE", pproheader[i].p_align);break;
//                        case PF_X|PF_R:
//                            printf("%-6s  %-lX\r\n", "R E", pproheader[i].p_align);break;
//                        case PF_W|PF_R:
//                            printf("%-6s  %-lX\r\n", "RW ", pproheader[i].p_align);break;
//                        case PF_X|PF_R|PF_W:
//                            printf("%-6s  %-lX\r\n", "RWE", pproheader[i].p_align);break;
//                        default:printf("\r\n");

//                            break;
//                    }


//                }
