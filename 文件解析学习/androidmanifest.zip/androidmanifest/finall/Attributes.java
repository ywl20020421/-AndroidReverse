package com.example.ndk.test.androidmanifest.finall;

import java.nio.ByteBuffer;
import java.util.ArrayList;

public class Attributes {
//    NamespaceUri	: 属性的命名空间 uri 在字符串池中的索引。此处很少会等于 -1
//    name 			: 属性名称在字符串池中的索引
//    valueStr 		: 属性值
//    type 			: 属性类型
//    data 			: 属性数据
   byte[] NamespaceUri;
   byte[] name;
   byte[] valueStr;
   byte[] type;
   byte[] data;

    public void show(ArrayList<String> strs){
        System.out.print("android："+ strs.get(ReaderUtil.bytestoint(name,0))+"=");
        int ty=ReaderUtil.bytestoint(type,0)>>24;
        if(ty==16){
            System.out.print("\""+ReaderUtil.bytestoint(data,0)+"\"\t");
        }if (ty==3) {
            System.out.print("\""+strs.get(ReaderUtil.bytestoint(valueStr,0))+"\"\t");
        }if(ty==1){
            System.out.print("\""+ReaderUtil.bytestohex(data,0)+"\"\t");
        }if (ty==18){
            if(ReaderUtil.bytestoint(data,0)==-1){
                System.out.print("\""+"ture"+"\"\t");
            }else {
                System.out.print("\""+"flase"+"\"\t");
            }
        }
    }

    public byte[] getbytes(){
        return ByteBuffer.allocate(20).put(NamespaceUri).put(name).put(valueStr).put(type).put(data).array();
    }

    public Attributes(byte[] bytes) {
        NamespaceUri=ReaderUtil.getbytes(bytes,0,4);
        name=ReaderUtil.getbytes(bytes,4,8);
        valueStr=ReaderUtil.getbytes(bytes,8,12);
        type=ReaderUtil.getbytes(bytes,12,16);
        data=ReaderUtil.getbytes(bytes,16,20);
    }

    public byte[] getNamespaceUri() {
        return NamespaceUri;
    }

    public void setNamespaceUri(byte[] namespaceUri) {
        NamespaceUri = namespaceUri;
    }

    public byte[] getName() {
        return name;
    }

    public void setName(byte[] name) {
        this.name = name;
    }

    public byte[] getValueStr() {
        return valueStr;
    }

    public void setValueStr(byte[] valueStr) {
        this.valueStr = valueStr;
    }

    public byte[] getType() {
        return type;
    }

    public void setType(byte[] type) {
        this.type = type;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
