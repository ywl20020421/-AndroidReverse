package com.example.ndk.test.androidmanifest.finall;

public class Chunk {
    byte[] chunkType =new byte[4]; // 标识不同 chunk 类型
    byte[] chunkSize =new byte[4]; // 该 chunk 字节数
    byte[] lineNumber=new byte[4]; // 行号
    byte[] Unknown   =new byte[4];
    byte[] data=null;

    public Chunk(byte[] data) {
        this.data = data;
        chunkType=ReaderUtil.getbytes(data,0,4);
        chunkSize=ReaderUtil.getbytes(data,4,8);
        lineNumber=ReaderUtil.getbytes(data,8,12);
        Unknown=ReaderUtil.getbytes(data,12,16);
    }

    public String show(){
        return null;
    }

}
