package com.example.ndk.test.androidmanifest.finall;

public class TextChunk extends Chunk{
    public TextChunk(byte[] data) {
        super(data);
    }
}
