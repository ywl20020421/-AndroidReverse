package com.example.ndk.test.androidmanifest.finall;

import static com.example.ndk.test.androidmanifest.finall.AndroidMinfestREADER.read;

public class example {
    public static void main(String[] args) {
        AndroidMinfestREADER read = read("C:\\Users\\calvin\\Desktop\\AndroidManifest88.xml");
        read.show();
    }
}
