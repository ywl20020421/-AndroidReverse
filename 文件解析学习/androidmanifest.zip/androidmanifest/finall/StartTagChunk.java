package com.example.ndk.test.androidmanifest.finall;

import java.nio.ByteBuffer;
import java.util.ArrayList;

public class StartTagChunk extends Chunk{
    byte[] Uri=new byte[4];
    byte[] Name=new byte[4];
    byte[] Flag=new byte[4];
    byte[] Attributecount=new byte[4];
    byte[] classAttributes=new byte[4];

    ArrayList<Attributes> attributes = new ArrayList<>();
    public StartTagChunk(byte[] data) {
        super(data);
        Uri=ReaderUtil.getbytes(data,16,20);
        Name=ReaderUtil.getbytes(data,20,24);
        Flag=ReaderUtil.getbytes(data,24,28);
        Attributecount=ReaderUtil.getbytes(data,28,32);
        classAttributes=ReaderUtil.getbytes(data,32,36);
        for (int i = 0; i < ReaderUtil.bytestoint(Attributecount, 0); i++) {
            attributes.add(new Attributes(ReaderUtil.getbytes(data,36+i*20,36+i*20+20)));
        }
    }

    public byte[] getbytes(){
        int i = ReaderUtil.bytestoint(super.chunkSize, 0);
        ByteBuffer allocate = ByteBuffer.allocate(i);
        allocate.put(chunkType).put(chunkSize).put(lineNumber).put(Unknown).put(Uri).put(Name).put(Flag).put(Attributecount).put(classAttributes);
        //allocate.limit(36);
        //allocate.

        //System.out.println(allocate.limit());
        for (Attributes attribute : attributes) {
            allocate.put(attribute.getbytes());
            //allocate.clear();
        }
        return allocate.array();
    }

}
