package com.example.ndk.test.androidmanifest.finall;

import java.util.ArrayList;

public class AMResourceIdChunk {
    /*
Chunk Type ： 4 字节，固定值，0x00080180，标识 ResourceId Chunk
Chunk Size ： 4 字节，标识此 Chunk 的字节数
ResourceIds ： int 数组，大小为 (chunkSize - 8) / 4
     */
    String ChunkType;
    int ChunkSize;
    ArrayList<String> ResourceIds=new ArrayList<>();
    byte[] data;

    @Override
    public String toString() {
        return "AMResourceIdChunk{\n" +
                "ChunkType='" + ChunkType + '\'' +
                "\nChunkSize=" + ChunkSize +
                "\nResourceIds=" + ResourceIds +"\n"+
                '}';
    }
    public void addid(String id){
        ResourceIds.add(id);
    }

    public byte[] getbytes(){
        int size=8+ResourceIds.size()*4;
        byte[] bytes = new byte[size];
        System.arraycopy(ReaderUtil.hextobytes(ChunkType,0),0,bytes,0,4);
        System.arraycopy(ReaderUtil.inttobytes(size,0),0,bytes,4,4);
        int index=0;
        for (int i = 0; i < ResourceIds.size(); i++) {
            System.arraycopy(ReaderUtil.hextobytes(ResourceIds.get(i),0),0,bytes,index+8,4);
            index+=4;
        }
        ChunkSize=size;
        data=bytes;
        return bytes;
    }
    public AMResourceIdChunk(byte[] data, int start) {
        byte[] chunktype = ReaderUtil.getbytes(data, 0+start, 4+start);
        byte[] chunksize = ReaderUtil.getbytes(data, 4+start, 8+start);
        ChunkSize=ReaderUtil.bytestoint(chunksize,0);
        ChunkType=ReaderUtil.bytestohex(chunktype,0);
        int index=0;
        for (int i = 0; i < (ChunkSize - 8) / 4; i++) {
            ResourceIds.add(ReaderUtil.bytestohex(ReaderUtil.getbytes(data, index+start+8, index + 4+start+8), 0));
            index+=4;
        }
    }
}
