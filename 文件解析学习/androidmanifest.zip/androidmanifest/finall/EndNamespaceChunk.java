package com.example.ndk.test.androidmanifest.finall;

import java.nio.ByteBuffer;

public class EndNamespaceChunk extends Chunk {

    byte[] Prefix=new byte[4];
    byte[] Uri=new byte[4];

    public EndNamespaceChunk(byte[] data) {
        super(data);
        Prefix=ReaderUtil.getbytes(data,16,20);
        Uri=ReaderUtil.getbytes(data,20,24);
    }
    public byte[] getbytes(){
        ByteBuffer allocate = ByteBuffer.allocate(ReaderUtil.bytestoint(super.chunkSize,0));
        allocate.put(chunkType).put(chunkSize).put(lineNumber).put(Unknown).put(Prefix).put(Uri);

        return allocate.array();
    }
}
