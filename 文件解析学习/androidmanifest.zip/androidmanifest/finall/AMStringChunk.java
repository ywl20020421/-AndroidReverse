package com.example.ndk.test.androidmanifest.finall;

import java.util.ArrayList;

public class AMStringChunk {
    /*
Chunk Type 			: 4 bytes，始终为 0x001c0001，标记这是 String Chunk
Chunk Size 			: 4 bytes，表示 String Chunk 的大小
String Count 		: 4 bytes，表示字符串的数量
Style Count 		: 4 bytes，表示样式的数量
Unkown 				: 4 bytes,固定值，0x00000000
String Pool Offset 	: 字符串池的偏移量，注意不是相对于文件开始处，而是相对于 String Chunk 的开始处
Style Pool Offset 	: 样式池的偏移量，同上，也是相对于 String Chunk 而言
String Offsets 		: int数组，大小为 String Count，存储每个字符串在字符串池中的相对偏移量
Style Offets 		: 同上，也是 int 数组。总大小为 Style Count * 4 bytes
String Pool 		: 字符串池，存储了所有的字符串
Style Pool 			: 样式池，存储了所有的样式
     */
    String ChunkType;//0
    int  ChunkSize;//4
    int  StringCount;//8
    int  StyleCount;//12
    int  Unkown;//16
    int  StringPoolOffset;//20
    int  StylePoolOffset;//
    int  StringOffsets;
    int  StyleOffets;

    public void addstr(String str){
//        byte[] bytes = ReaderUtil.utf8to16(str);
//        ChunkSize+=bytes.length;
//        StringPool.add(str);
    }
    ArrayList<String> StringPool=new ArrayList<>();//字符串常量池
    ArrayList<String> StylePool=new ArrayList<>();//样式池

    public  byte[] getbytes(){
        int Stringsize = 0;
        for (int i = 0; i < StringPool.size(); i++) {
            Stringsize+=2;
            Stringsize+=StringPool.get(i).length()*2;
            Stringsize+=2;
        }
        int stylepoolsize = 0;
        for (int i = 0; i < StylePool.size(); i++) {
            stylepoolsize+=2;
            stylepoolsize+=StylePool.get(i).length()*2;
            stylepoolsize+=2;
        }
        int datasize=StringPoolOffset+Stringsize;
        byte[] databytes = new byte[datasize];//字符模块总大小
        byte[] bytes = new byte[Stringsize];//字符池大小
        int index=0;
        for (int i = 0; i < StringPool.size(); i++) {
            String s = StringPool.get(i);
            byte[] u16 = ReaderUtil.utf8to16(s);
            //byte[] datastr = new byte[u16.length + 4];
           // System.arraycopy(ReaderUtil.inttobytes(s.length(),0),0,datastr,0,2);
            //System.arraycopy(ReaderUtil.utf8to16(s),2,datastr,0,ReaderUtil.utf8to16(s).length);

            System.arraycopy(u16,0,bytes,index,u16.length);
            index+=u16.length;
            //index+=4;
        }
        System.arraycopy(bytes,0,databytes,StringPoolOffset,Stringsize);
       // System.arraycopy();
        System.arraycopy(this.data,0,databytes,0,StringPoolOffset);
        byte[] size = ReaderUtil.inttobytes(datasize, 0);
        byte[] count = ReaderUtil.inttobytes(StringPool.size(), 0);
        System.arraycopy(size,0,databytes,4,4);
        System.arraycopy(count,0,databytes,8,4);
        this.data=databytes;
        return databytes;

    }
    public String getChunkType() {
        return ChunkType;
    }

    public void setChunkType(String chunkType) {
        ChunkType = chunkType;
    }

    public int getChunkSize() {
        return ChunkSize;
    }

    public void setChunkSize(int chunkSize) {
        ChunkSize = chunkSize;
    }

    public int getStringCount() {
        return StringCount;
    }

    public void setStringCount(int stringCount) {
        StringCount = stringCount;
    }

    public int getStyleCount() {
        return StyleCount;
    }

    public void setStyleCount(int styleCount) {
        StyleCount = styleCount;
    }

    public int getUnkown() {
        return Unkown;
    }

    public void setUnkown(int unkown) {
        Unkown = unkown;
    }

    public int getStringPoolOffset() {
        return StringPoolOffset;
    }

    public void setStringPoolOffset(int stringPoolOffset) {
        StringPoolOffset = stringPoolOffset;
    }

    public int getStylePoolOffset() {
        return StylePoolOffset;
    }

    public void setStylePoolOffset(int stylePoolOffset) {
        StylePoolOffset = stylePoolOffset;
    }

    public int getStringOffsets() {
        return StringOffsets;
    }

    public void setStringOffsets(int stringOffsets) {
        StringOffsets = stringOffsets;
    }

    public int getStyleOffets() {
        return StyleOffets;
    }

    public void setStyleOffets(int styleOffets) {
        StyleOffets = styleOffets;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    byte[] data;
    int Stringindex=0;
    int Styleindex=0;
    public AMStringChunk(byte[] data,int begin) {
         this.ChunkSize = ReaderUtil.readbasesize(data, begin);
         this.data=new byte[ChunkSize];
         System.arraycopy(data,begin,this.data,0,this.ChunkSize);
        initialization();
    }

    @Override
    public String toString() {
        return "AMStringChunk{" +
                "\nChunkType='" + ChunkType + '\'' +
                "\nChunkSize=" + ChunkSize +
                "\nStringCount=" + StringCount +
                "\nStyleCount=" + StyleCount +
                "\nUnkown=" + Unkown +
                "\nStringPoolOffset=" + StringPoolOffset +
                "\nStylePoolOffset=" + StylePoolOffset +
                "\nStringOffsets=" + StringOffsets +
                "\nStyleOffets=" + StyleOffets +
                "\nStringPool=" + StringPool.size() +
                "\nStylePool=" + StylePool +"\n"+
                '}';
    }

    private void initialization() {
        ChunkType=ReaderUtil.bytestohex(ReaderUtil.getbytes(data,0,4),0);
        StringCount=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,8,12),0);
        StyleCount=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,12,16),0);
        Unkown=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,16,20),0);
        StringPoolOffset=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,20,24),0);
        StylePoolOffset=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,24,28),0);
        StringOffsets=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,28,32),0);
        StyleOffets=ReaderUtil.bytestoint(ReaderUtil.getbytes(data,32,36),0);
        initializationStringPool();
        initializationStylePool();
    }

    private void initializationStylePool() {
        Styleindex=StyleOffets;
        for (int i = 0; i < StyleCount; i++) {

            int size = ReaderUtil.bytestoint(ReaderUtil.getbytes(data, Styleindex, Styleindex + 2), 0);
            Styleindex+=2;
            String str = ReaderUtil.readutf16(ReaderUtil.getbytes(data, Styleindex, Styleindex + size * 2));
            Styleindex=Styleindex + size * 2;
            Styleindex+=2;
            StylePool.add(str);
            //System.out.println(str);

        }

    }

    private void initializationStringPool() {
        Stringindex=StringPoolOffset;
        for (int i = 0; i < StringCount; i++) {
            int size = ReaderUtil.bytestoint(ReaderUtil.getbytes(data, Stringindex, Stringindex + 2), 0);
            Stringindex+=2;
            String str = ReaderUtil.readutf16(ReaderUtil.getbytes(data, Stringindex, Stringindex + size * 2));
            Stringindex=Stringindex + size * 2;
            Stringindex+=2;
            StringPool.add(str);
            //System.out.println(str);
        }


    }
}
