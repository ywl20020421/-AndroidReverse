package com.example.ndk.test.androidmanifest.finall;

import java.nio.ByteBuffer;

public class EndTagChunk extends Chunk{
    byte[] Uri=new byte[4];
    byte[] Name=new byte[4];
    public EndTagChunk(byte[] data) {
        super(data);
        Uri=ReaderUtil.getbytes(data,20,24);
        Name=ReaderUtil.getbytes(data,16,20);
    }
    public byte[] getbytes(){
        ByteBuffer allocate = ByteBuffer.allocate(ReaderUtil.bytestoint(super.chunkSize,0));
        allocate.put(chunkType).put(chunkSize).put(lineNumber).put(Unknown).put(Name).put(Uri);

        return allocate.array();
    }
}
