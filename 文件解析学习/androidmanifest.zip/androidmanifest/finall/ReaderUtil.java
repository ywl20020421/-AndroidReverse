package com.example.ndk.test.androidmanifest.finall;

import androidx.annotation.NonNull;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class ReaderUtil {

    /*
    data:源数据
    调换数据顺序
     */
    public static byte[] exchangeBytes(byte[] data){
        byte[] bytes = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            bytes[i]=data[data.length-1-i];
        }
        return bytes;
    }

    /*
    data 数据源
    flag 判断大端序 1还是小端序 0
    将byte数据转换为int
     */
    public static int bytestoint(byte[] data ,int flag){

        if(data.length==2){
            byte[] bytes = new byte[4];
            System.arraycopy(data,0,bytes,0,2);
            data=bytes;
        }
        if(flag==1){
            return ByteBuffer.wrap(data).getInt();
        }
        return ByteBuffer.wrap(exchangeBytes(data)).getInt();

    }

    /*
    data 需要转换的数据
    flag 判断大小端绪 0为小端序
    将int转换为byte[]
     */
    public static byte[] inttobytes(int data ,int flag){
            if(flag==1){
                return ByteBuffer.allocate(4).putInt(data).array();
            }
            return exchangeBytes(ByteBuffer.allocate(4).putInt(data).array());
    }

    /*
    将字节数组转换为十六进制
     */
    public static String bytestohex(byte[] data,int flag){
        if (flag!=1){
            data= exchangeBytes(data);
        }
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
            int num=(data[i]&0xff);
            String s = Integer.toHexString(num);
            if(s.length()<2){
                sb.append(0);
            }
            sb.append(s);
        }
        return sb.toString();
    }

    /*
    hex：需要转换的十六进制
    flag：大小端序
     */
    public static byte[] hextobytes(String hex,int flag){
        byte[] result = new byte[hex.length() / 2];
        char[] chars = hex.toCharArray();
        for (int i = 0, j = 0; i < result.length; i++) {
            result[i] = (byte) (toByte(chars[j++]) << 4 | toByte(chars[j++]));
        }
        if (flag==0){
            result=exchangeBytes(result);
        }
        return result;
    }
    private static int toByte(char c) {
        if (c >= '0' && c <= '9') return (c - '0');
        if (c >= 'A' && c <= 'F') return (c - 'A' + 0x0A);
        if (c >= 'a' && c <= 'f') return (c - 'a' + 0x0a);
        throw new RuntimeException("invalid hex char '" + c + "'");
    }

    /*
    str:需要转换的字符串
    将utf-8 转换为有大小的utf-16
     */
    public static byte[] utf8to16(String str)  {
        byte[] bytes=null;
        try {
            bytes = str.getBytes("utf-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        byte[] data = new byte[bytes.length*2 + 4];
        byte[] array = ByteBuffer.allocate(2).putChar((char)bytes.length).array();
        array=exchangeBytes(array);
        System.arraycopy(array,0,data,0,2);
        for (int i = 0; i < bytes.length; i++) {
            data[i*2+2]=bytes[i];
            data[i*2+2+1]=0;
        }
        byte[] end = {00,00};
        System.arraycopy(end,0,data,data.length-2-1,2);
        return data;
    }

    public static String readutf16(byte[] data){
        byte[] bytes = new byte[data.length / 2];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i]=data[2*i];
        }
        return new String(bytes);

    }

    public static int readbasesize(byte[] bytes,int start)
    {
        byte[] size = new byte[4];
        System.arraycopy(bytes,start+4,size,0,4);
        int i = bytestoint(size,0);
        return i;
    }

    public static byte[] getbytes(byte[] data,int start,int end){
        byte[] bytes = new byte[end - start];
        System.arraycopy(data,start,bytes,0,end-start);
        return bytes;
    }



}
