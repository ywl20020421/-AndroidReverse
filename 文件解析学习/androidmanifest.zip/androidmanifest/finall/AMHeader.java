package com.example.ndk.test.androidmanifest.finall;

public class AMHeader {
    byte[] data=new byte[8];
    String magic=null;
    int size=0;

    public String getMagic() {
        return magic;
    }

    public byte[] getData(){
        return data;
    }
    public void setMagic(String magic) {
        this.magic = magic;
        byte[] hextobytes = ReaderUtil.hextobytes(magic, 0);
        System.arraycopy(hextobytes,0,data,0,4);
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
        byte[] inttobytes = ReaderUtil.inttobytes(size, 0);
        System.arraycopy(inttobytes,0,data,4,4);

    }

    @Override
    public String toString() {
        String flag="";
        if("00080003".equals(magic)){
            flag="符合Anderoidmanifest文件格式";
        }

        return "AMHeader{" +
                "\nmagic='" + magic + '\'' +flag+
                "\nsize=" + size +"\n"+
                '}';
    }

    public AMHeader(byte[] data, int begin) {
        System.arraycopy(data,begin,this.data,0,8);
        initialization();
    }
    private  void initialization() {
        byte[] magicb = new byte[4];
        byte[] sizeb = new byte[4];
        System.arraycopy(this.data,0,magicb,0,4);
        System.arraycopy(this.data,4,sizeb,0,4);
        magic=ReaderUtil.bytestohex(magicb,0);
        size=ReaderUtil.bytestoint(sizeb,0);
    }

}
