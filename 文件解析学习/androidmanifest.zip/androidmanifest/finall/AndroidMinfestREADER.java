package com.example.ndk.test.androidmanifest.finall;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

public class AndroidMinfestREADER {
    static String TAG="Androidmanifest文件解析";
    AMHeader header=null;                          //头部分
    AMStringChunk stringChunk=null;                //字符模块
    int stringChunksize;
    AMResourceIdChunk resourceIdChunk=null;        //资源id模块
    int resourceIdChunksize;
    AMXmlContentChunk xmlContentChunk=null;        //清单文件的详细信息模块
    byte[] data;

//    public static void main(String[] args) {
//
//        //read.show();
//        //System.out.println(read.xmlContentChunk.getbytes().length);
//        //read.stringChunk.StringPool.add("helloworld");
//        //read.setData();
//        //
//        //read.save("C:\\Users\\calvin\\Desktop\\AndroidManifest88.xml");
//
//    }
    public void show(){
        xmlContentChunk.show(stringChunk.StringPool);
    }
    private  void initialization() {
        header=new AMHeader(data,0);
        stringChunk=new AMStringChunk(data,8);
        stringChunksize=stringChunk.ChunkSize;
        resourceIdChunk=new AMResourceIdChunk(data,8+stringChunksize);
        resourceIdChunksize=resourceIdChunk.ChunkSize;
        xmlContentChunk=new AMXmlContentChunk(data,8+stringChunksize+resourceIdChunksize,header.size);
    }

    /*
    url配置文件的路径
    返回配置文件对象
     */
    public static AndroidMinfestREADER read(String url){
        AndroidMinfestREADER am=null;
        File file = new File(url);
        FileInputStream fs=null;
        ByteArrayOutputStream baos=null;
        if (file.exists()){
            try {
                fs = new FileInputStream(file);
                baos =new ByteArrayOutputStream();

                int len=0;
                byte[] bytes = new byte[1024];

                while ((len=fs.read(bytes))!=-1){
                    baos.write(bytes,0,len);
                }
                am=new AndroidMinfestREADER(baos.toByteArray());

                fs.close();
                baos.close();

            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        }

        return am;
    }




    public AndroidMinfestREADER(byte[] data) {
        this.data = data;
        initialization();
    }

    public void setData(){
        ByteBuffer allocate = ByteBuffer.allocate(8 + stringChunk.getbytes().length + resourceIdChunk.getbytes().length + xmlContentChunk.getbytes().length);
        data=allocate.put(header.data).put(stringChunk.getbytes()).put(resourceIdChunk.getbytes()).put(xmlContentChunk.getbytes()).array();
    }
    /*
    url 保存到的路劲
     */
    public void save(String url){
        File file = new File(url);
        if(data==null){
            return;
        }
        FileOutputStream fileOutputStream=null;
        try {
            fileOutputStream= new FileOutputStream(file);
            fileOutputStream.write(data);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        //Log.d(TAG, "save: 保存完毕！");
        System.out.println("保存完毕！");
    }
}
