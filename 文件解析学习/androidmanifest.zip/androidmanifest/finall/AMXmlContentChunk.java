package com.example.ndk.test.androidmanifest.finall;

import java.nio.ByteBuffer;
import java.util.ArrayList;

public class AMXmlContentChunk {
    byte[] data;
    //StartNamespaceChunk startNamespaceChunk;
    ArrayList<Chunk> xml=new ArrayList<>();

    //ArrayList<StartTagChunk> startTagChunks=new ArrayList<>();
    public AMXmlContentChunk(byte[] bytes,int start,int end){
        data=new byte[end-start];
        System.arraycopy(bytes,start,this.data,0,end-start);
        init();
    }
    int index=0;
    int kongge=0;
    private void init() {
//        int readbasesize = ReaderUtil.readbasesize(data, index);
//        startNamespaceChunk=new StartNamespaceChunk(ReaderUtil.getbytes(data,0,readbasesize));
//        xml.add(startNamespaceChunk);
//        index+=readbasesize;
        while(index<data.length){
            int size = ReaderUtil.readbasesize(data, index);

            Chunk chunk = new Chunk(ReaderUtil.getbytes(data, index, index + size));
            switch (ReaderUtil.bytestoint(chunk.chunkType,0)){
                case 1048832:  //start Namespace Chunk

                    //System.out.println("start Namespace Chunk");
                    xml.add(new StartNamespaceChunk(chunk.data));
                    break;
                case 1048833: //End start Namespace Chunk
                    //System.out.println("End Namespace Chunk");
                    xml.add(new EndNamespaceChunk(chunk.data));
                    break;
                case 1048834:  //Start Tag Chunk
                    //System.out.println("start Tag Chunk");
                    xml.add(new StartTagChunk(chunk.data));
                    break;
                case 1048835:  //End Start Tag Chunk
                    //System.out.println("End Start Tag Chunk");
                    xml.add(new EndTagChunk(chunk.data));
                    break;
                case 1048836:  //Text Chunk
                    break;


            }

            //xml.add(chunk);
            index+=size;
            //System.out.println(ReaderUtil.bytestoint(chunk.chunkType,0)+" \t"+ReaderUtil.bytestohex(chunk.chunkType,0));

        }


    }
    private void choiceshow(int index,ArrayList<String> strs){
        if (index>=0&&index<strs.size()){
            System.out.print(strs.get(index));
        }

    }

    //将字符池传入  即可显示
    public void show(ArrayList<String> strs){
        for (int i = 0; i < xml.size(); i++) {
            //System.out.println(i);
            ChunkShow(xml.get(i),strs);
        }
    }
    public void ChunkShow(Chunk chunk,ArrayList<String> strs){
        int Uri;
        int Prefix;
        int Name;
        int Attributecount;
        int Size;
        switch (ReaderUtil.bytestoint(chunk.chunkType,0)){

            case 1048832:  //start Namespace Chunk

                for (int i = 0; i < kongge; i++) {
                    System.out.print("\t");
                }
                kongge++;
                //System.out.println("start Namespace Chunk");
                StartNamespaceChunk startNamespaceChunk1=new StartNamespaceChunk(chunk.data);
                Uri= ReaderUtil.bytestoint(startNamespaceChunk1.Uri, 0);
                Prefix= ReaderUtil.bytestoint(startNamespaceChunk1.Prefix, 0);
                //System.out.println((Uri));
                System.out.println("\n<");
                choiceshow(Uri,strs);
                System.out.print(" = ");
                choiceshow(Prefix,strs);
                System.out.print("\t");

                break;
            case 1048833: //End start Namespace Chunk
                //System.out.println("End Namespace Chunk");

                kongge--;
                for (int i = 0; i < kongge; i++) {
                    System.out.print("\t");
                }

                EndNamespaceChunk endNamespaceChunk=new EndNamespaceChunk(chunk.data);
                Uri = ReaderUtil.bytestoint(endNamespaceChunk.Uri, 0);
                Prefix = ReaderUtil.bytestoint(endNamespaceChunk.Prefix, 0);
                System.out.print(">\n");

                //System.out.println((Uri));
                //choiceshow(Uri,strs);
                //choiceshow(Prefix,strs);
                break;
            case 1048834:  //Start Tag Chunk
                //System.out.println("start Tag Chunk");

                for (int i = 0; i < kongge; i++) {
                    System.out.print("\t");
                }
                kongge++;
                StartTagChunk startTagChunk=new StartTagChunk(chunk.data);
                Uri = ReaderUtil.bytestoint(startTagChunk.Uri, 0);
                Name = ReaderUtil.bytestoint(startTagChunk.Name, 0);
                Attributecount=ReaderUtil.bytestoint(startTagChunk.Attributecount, 0);
                ArrayList<Attributes> attributes = new ArrayList<>();
                System.out.println("\n<");
                choiceshow(Name,strs);
                System.out.print("\t");
                int index=0;
                for (int i = 0; i < Attributecount; i++) {
                    Attributes ab = new Attributes(ReaderUtil.getbytes(chunk.data, index + 36, index + 36 + 20));
                    attributes.add(ab);
                    ab.show(strs);
                    index+=20;
                }
                //startTagChunk.attributes=attributes;
                //startTagChunks.add(startTagChunk);

                //System.out.println((Name));
                //choiceshow(Uri,strs);
                //choiceshow(Name,strs);

                break;
            case 1048835:  //End Start Tag Chunk
                //System.out.println("End Start Tag Chunk");

                kongge--;
                for (int i = 0; i < kongge; i++) {
                    System.out.print("\t");
                }
                EndTagChunk endTagChunk=new EndTagChunk(chunk.data);
                Uri= ReaderUtil.bytestoint(endTagChunk.Uri, 0);
                Prefix= ReaderUtil.bytestoint(endTagChunk.Name, 0);
                System.out.print(">\n");
                //System.out.println((Prefix));
                //choiceshow(Uri,strs);
                //choiceshow(Prefix,strs);
                break;
            case 1048836:  //Text Chunk
                break;


        }
    }

    public byte[] getbytes() {
        int size=0;
        for (Chunk chunk : xml) {
            size+=ReaderUtil.bytestoint(chunk.chunkSize,0);
        }
        ByteBuffer allocate=ByteBuffer.allocate(size);
        for (Chunk chunk : xml) {
            switch (ReaderUtil.bytestoint(chunk.chunkType, 0)) {

                case 1048832:  //start Namespace Chunk
                    StartNamespaceChunk a = (StartNamespaceChunk) chunk;
                    allocate.put(a.getbytes());

                    break;
                case 1048833: //End start Namespace Chunk
                    //System.out.println("End Namespace Chunk");
                    EndNamespaceChunk b = (EndNamespaceChunk) chunk;
                    allocate.put(b.getbytes());

                    break;
                case 1048834:  //Start Tag Chunk
                    //System.out.println("start Tag Chunk");

                    StartTagChunk c = (StartTagChunk) chunk;
                    allocate.put(c.getbytes());

                    break;
                case 1048835:  //End Start Tag Chunk
                    //System.out.println("End Start Tag Chunk");

                    EndTagChunk d = (EndTagChunk) chunk;
                    allocate.put(d.getbytes());
                    break;
                case 1048836:  //Text Chunk
                    break;

            }


        }
        return allocate.array();
    }

}
