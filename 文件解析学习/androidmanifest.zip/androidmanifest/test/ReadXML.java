package com.example.ndk.test.androidmanifest.test;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class ReadXML {
    static byte[] XMLHEADER=new byte[8];//头文件部分

    static HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();//键值对应  字符串index
    static int StringChunkOver;//字符串池末位位置
    static int ResourceIdChunksize;//资源模块大小
    static int StartNamespaceChunksize;//命名模块大小

    static int StartTagChunksize;//开始模块大小

    static int endTagChunksize;

    static int Textchunksize;

    static int endTextchunksize;

    static int nextTextchunksize;
    static int nextTextchunk2size;
    static int nextTextchunk3size;
    static int nextTextchunk4size;
    static int nextTextchunk5size;
    static int nextTextchunk6size;
    static int nextTextchunk7size=1;

    static int indexFinall;
    static ArrayList<String> strings = new ArrayList<>();//所有字符串
    static String TAG = "配置解析";

    public static void main(String[] args) {
        byte[] bytes = readXml("C:\\Users\\calvin\\Desktop\\AndroidManifest.xml");
        readXmlHeader(bytes);
        //System.out.println(bytes.length);
        readStringChunk(bytes);
        readResourceIdChunk(bytes);
        readStartNamespaceChunk(bytes);
        StartTagChunk(bytes);
        endTagChunk(bytes);
        Textchunk(bytes);
        endTextchunk(bytes);
        nextTextchunk(bytes);
        nextTextchunk2(bytes);
        nextTextchunk3(bytes);
        for (int i = 0; i < 12; i++) {
            nextTextchunk3(bytes);
        }
        //readEndNamespaceChunk(bytes);
    }
    private static void nextTextchunk3(byte[] bytes) {
        byte[] chunkType = new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize = new byte[4]; // 该 chunk 字节数
        byte[] lineNumber = new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        int aa=indexFinall;
        System.arraycopy(bytes,aa,chunkType,0,4);
        System.arraycopy(bytes,aa+4,chunkSize,0,4);
        System.arraycopy(bytes,aa+8,lineNumber,0,4);
        System.arraycopy(bytes,aa+12,Unknown,0,4);
        System.arraycopy(bytes,aa+16,Uri,0,4);
        System.arraycopy(bytes,aa+20,Name,0,4);
        System.arraycopy(bytes,aa+24,Flag,0,4);
        System.arraycopy(bytes,aa+28,Attributecount,0,4);
        System.arraycopy(bytes,aa+32,classAttributes,0,4);


        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);
        Attributecount=bytesDisplace(Attributecount);
        classAttributes=bytesDisplace(classAttributes);

        System.out.println("..........nextTextchunk"+nextTextchunk7size+"...........");
        nextTextchunk7size++;
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        //nextTextchunk2size=HexToInt(bytesToHexString(chunkSize));
        //endTextchunk=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+strings.get(HexToInt(bytesToHexString(Name))));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        indexFinall+=HexToInt(bytesToHexString(chunkSize));
        if(HexToInt(bytesToHexString(chunkSize))==24){
            return;
        }
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));
        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
        byte[] data = new byte[Attributecounts*5*4];
        System.out.println("***************************************************");
        System.arraycopy(bytes,aa+36,data,0,Attributecounts*5*4);
        for (int i = 0; i < Attributecounts; i++) {
            for (int i1 = 0; i1 < 5; i1++) {
                byte[] d = new byte[4];
                System.arraycopy(data,i*5*4+i1*4,d,0,4);
                switch (i1){
                    case 0:
                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("dnameSpace:");
                        showInt(dnameSpace);
                        break;
                    case 1:
                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("Uri:");
                        showInt(dUri);
                        break;
                    case 2:
                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("name:");
                        showInt(dname);
                        break;
                    case 3:
                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
                        System.out.print("valueString:");
                        showInt(dvalueString);
                        break;
                    case 4:
                        //int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.println("ddata:"+bytesToHexString(bytesDisplace(d)));
                        //showInt(ddata);
                        break;

                }
            }

        }

    }
    private static void nextTextchunk2(byte[] bytes) {
        byte[] chunkType = new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize = new byte[4]; // 该 chunk 字节数
        byte[] lineNumber = new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        int aa=StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+endTagChunksize+Textchunksize+endTextchunksize+nextTextchunksize;
        System.arraycopy(bytes,aa,chunkType,0,4);
        System.arraycopy(bytes,aa+4,chunkSize,0,4);
        System.arraycopy(bytes,aa+8,lineNumber,0,4);
        System.arraycopy(bytes,aa+12,Unknown,0,4);
        System.arraycopy(bytes,aa+16,Uri,0,4);
        System.arraycopy(bytes,aa+20,Name,0,4);
        System.arraycopy(bytes,aa+24,Flag,0,4);
        System.arraycopy(bytes,aa+28,Attributecount,0,4);
        System.arraycopy(bytes,aa+32,classAttributes,0,4);


        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);
        Attributecount=bytesDisplace(Attributecount);
        classAttributes=bytesDisplace(classAttributes);

        System.out.println("..........nextTextchunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        nextTextchunk2size=HexToInt(bytesToHexString(chunkSize));
        //endTextchunk=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+strings.get(HexToInt(bytesToHexString(Name))));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));
        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
        byte[] data = new byte[Attributecounts*5*4];
        System.out.println("***************************************************");
        System.arraycopy(bytes,aa+36,data,0,Attributecounts*5*4);
        for (int i = 0; i < Attributecounts; i++) {
            for (int i1 = 0; i1 < 5; i1++) {
                byte[] d = new byte[4];
                System.arraycopy(data,i*5*4+i1*4,d,0,4);
                switch (i1){
                    case 0:
                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("dnameSpace:");
                        showInt(dnameSpace);
                        break;
                    case 1:
                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("Uri:");
                        showInt(dUri);
                        break;
                    case 2:
                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("name:");
                        showInt(dname);
                        break;
                    case 3:
                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
                        System.out.print("valueString:");
                        showInt(dvalueString);
                        break;
                    case 4:
                        //int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.println("ddata:"+bytesToHexString(bytesDisplace(d)));
                        //showInt(ddata);
                        break;

                }
            }

        }

        indexFinall=aa;
        indexFinall+=HexToInt(bytesToHexString(chunkSize));
    }
    private static void nextTextchunk(byte[] bytes) {
        byte[] chunkType = new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize = new byte[4]; // 该 chunk 字节数
        byte[] lineNumber = new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        int aa=StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+endTagChunksize+Textchunksize+endTextchunksize;
        System.arraycopy(bytes,aa,chunkType,0,4);
        System.arraycopy(bytes,aa+4,chunkSize,0,4);
        System.arraycopy(bytes,aa+8,lineNumber,0,4);
        System.arraycopy(bytes,aa+12,Unknown,0,4);
        System.arraycopy(bytes,aa+16,Uri,0,4);
        System.arraycopy(bytes,aa+20,Name,0,4);
        System.arraycopy(bytes,aa+24,Flag,0,4);
        System.arraycopy(bytes,aa+28,Attributecount,0,4);
        System.arraycopy(bytes,aa+32,classAttributes,0,4);


        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);
        Attributecount=bytesDisplace(Attributecount);
        classAttributes=bytesDisplace(classAttributes);

        System.out.println("..........nextTextchunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        nextTextchunksize=HexToInt(bytesToHexString(chunkSize));
        //endTextchunk=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+strings.get(HexToInt(bytesToHexString(Name))));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));
        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
        byte[] data = new byte[Attributecounts*5*4];
        System.out.println("***************************************************");
        System.arraycopy(bytes,aa+36,data,0,Attributecounts*5*4);
        for (int i = 0; i < Attributecounts; i++) {
            for (int i1 = 0; i1 < 5; i1++) {
                byte[] d = new byte[4];
                System.arraycopy(data,i*5*4+i1*4,d,0,4);
                switch (i1){
                    case 0:
                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("dnameSpace:");
                        showInt(dnameSpace);
                        break;
                    case 1:
                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("Uri:");
                        showInt(dUri);
                        break;
                    case 2:
                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("name:");
                        showInt(dname);
                        break;
                    case 3:
                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
                        System.out.print("valueString:");
                        showInt(dvalueString);
                        break;
                    case 4:
                        //int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.println("ddata:"+bytesToHexString(bytesDisplace(d)));
                        //showInt(ddata);
                        break;

                }
            }

        }


    }

    private static void endTextchunk(byte[] bytes) {
        byte[] chunkType = new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize = new byte[4]; // 该 chunk 字节数
        byte[] lineNumber = new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        int aa=StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+endTagChunksize+Textchunksize;
        System.arraycopy(bytes,aa,chunkType,0,4);
        System.arraycopy(bytes,aa+4,chunkSize,0,4);
        System.arraycopy(bytes,aa+8,lineNumber,0,4);
        System.arraycopy(bytes,aa+12,Unknown,0,4);
        System.arraycopy(bytes,aa+16,Uri,0,4);
        System.arraycopy(bytes,aa+20,Name,0,4);
        System.arraycopy(bytes,aa+24,Flag,0,4);
        System.arraycopy(bytes,aa+28,Attributecount,0,4);
        System.arraycopy(bytes,aa+32,classAttributes,0,4);


        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);
        Attributecount=bytesDisplace(Attributecount);
        classAttributes=bytesDisplace(classAttributes);

        System.out.println("..........endTextchunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        endTextchunksize=HexToInt(bytesToHexString(chunkSize));
        //endTextchunk=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+strings.get(HexToInt(bytesToHexString(Name))));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));
        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
        byte[] data = new byte[Attributecounts*5*4];
        System.out.println("***************************************************");
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+endTagChunksize+Textchunksize+36,data,0,Attributecounts*5*4);
        for (int i = 0; i < Attributecounts; i++) {
            for (int i1 = 0; i1 < 5; i1++) {
                byte[] d = new byte[4];
                System.arraycopy(data,i*5*4+i1*4,d,0,4);
                switch (i1){
                    case 0:
                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("dnameSpace:");
                        showInt(dnameSpace);
                        break;
                    case 1:
                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("Uri:");
                        showInt(dUri);
                        break;
                    case 2:
                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("name:");
                        showInt(dname);
                        break;
                    case 3:
                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
                        System.out.print("valueString:");
                        showInt(dvalueString);
                        break;
                    case 4:
                        //int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.println("ddata:"+bytesToHexString(bytesDisplace(d)));
                        //showInt(ddata);
                        break;

                }
            }

        }


    }
    private static void Textchunk(byte[] bytes) {
        byte[] chunkType = new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize = new byte[4]; // 该 chunk 字节数
        byte[] lineNumber = new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        int aa=StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+endTagChunksize;
        System.arraycopy(bytes,aa,chunkType,0,4);
        System.arraycopy(bytes,aa+4,chunkSize,0,4);
        System.arraycopy(bytes,aa+8,lineNumber,0,4);
        System.arraycopy(bytes,aa+12,Unknown,0,4);
        System.arraycopy(bytes,aa+16,Uri,0,4);
        System.arraycopy(bytes,aa+20,Name,0,4);
        System.arraycopy(bytes,aa+24,Flag,0,4);


        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);

        System.out.println("..........Textchunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        Textchunksize=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+strings.get(HexToInt(bytesToHexString(Name))));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));
//        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
//        byte[] data = new byte[Attributecounts*5*4];
//        System.out.println("***************************************************");
//        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+endTagChunksize+36,data,0,Attributecounts*5*4);
//        for (int i = 0; i < Attributecounts; i++) {
//            for (int i1 = 0; i1 < 5; i1++) {
//                byte[] d = new byte[4];
//                System.arraycopy(data,i*5*4+i1*4,d,0,4);
//                switch (i1){
//                    case 0:
//                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
//                        System.out.print("dnameSpace:");
//                        showInt(dnameSpace);
//                        break;
//                    case 1:
//                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
//                        System.out.print("Uri:");
//                        showInt(dUri);
//                        break;
//                    case 2:
//                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
//                        System.out.print("name:");
//                        showInt(dname);
//                        break;
//                    case 3:
//                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
//                        System.out.print("valueString:");
//                        showInt(dvalueString);
//                        break;
//                    case 4:
//                        int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
//                        System.out.print("ddata:");
//                        showInt(ddata);
//                        break;
//
//                }
//            }
//
//        }


    }
    private static void endTagChunk(byte[] bytes) {
        byte[] chunkType = new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize = new byte[4]; // 该 chunk 字节数
        byte[] lineNumber = new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        int aa=StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize;
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize,chunkType,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+4,chunkSize,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+8,lineNumber,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+12,Unknown,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+16,Uri,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+20,Name,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+24,Flag,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+28,Attributecount,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+32,classAttributes,0,4);

        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);
        Attributecount=bytesDisplace(Attributecount);
        classAttributes=bytesDisplace(classAttributes);

        System.out.println("..........End TagChunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        endTagChunksize=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+strings.get(HexToInt(bytesToHexString(Name))));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));
        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
        byte[] data = new byte[Attributecounts*5*4];
        System.out.println("***************************************************");
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+StartTagChunksize+36,data,0,Attributecounts*5*4);
        for (int i = 0; i < Attributecounts; i++) {
            for (int i1 = 0; i1 < 5; i1++) {
                byte[] d = new byte[4];
                System.arraycopy(data,i*5*4+i1*4,d,0,4);
                switch (i1){
                    case 0:
                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("dnameSpace:");
                        showInt(dnameSpace);
                        break;
                    case 1:
                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("Uri:");
                        showInt(dUri);
                        break;
                    case 2:
                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("name:");
                        showInt(dname);
                        break;
                    case 3:
                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
                        System.out.print("valueString:");
                        showInt(dvalueString);
                        break;
                    case 4:
                        int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("ddata:");
                        showInt(ddata);
                        break;

                }
            }

        }


    }
    private static void StartTagChunk(byte[] bytes) {
        byte[] chunkType=new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize=new byte[4]; // 该 chunk 字节数
        byte[] lineNumber=new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Uri=new byte[4];
        byte[] Name=new byte[4];
        byte[] Flag=new byte[4];
        byte[] Attributecount=new byte[4];
        byte[] classAttributes=new byte[4];

        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize,chunkType,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+4,chunkSize,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+8,lineNumber,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+12,Unknown,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+16,Uri,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+20,Name,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+24,Flag,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+28,Attributecount,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+32,classAttributes,0,4);


        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Name=bytesDisplace(Name);
        Uri=bytesDisplace(Uri);
        Flag=bytesDisplace(Flag);
        Attributecount=bytesDisplace(Attributecount);
        classAttributes=bytesDisplace(classAttributes);

        System.out.println("..........Start Tag Chunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        StartTagChunksize=HexToInt(bytesToHexString(chunkSize));
        //StartNamespaceChunksize+=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Name:"+HexToInt(bytesToHexString(Name)));//HexToInt
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("Flag:"+(bytesToHexString(Flag)));
        System.out.println("Attributecount:"+HexToInt(bytesToHexString(Attributecount)));
        System.out.println("classAttributes:"+HexToInt(bytesToHexString(classAttributes)));

        int Attributecounts=HexToInt(bytesToHexString(Attributecount));
        byte[] data = new byte[Attributecounts*5*4];
        System.out.println("***************************************************");
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+StartNamespaceChunksize+36,data,0,Attributecounts*5*4);
        for (int i = 0; i < Attributecounts; i++) {
            for (int i1 = 0; i1 < 5; i1++) {
                byte[] d = new byte[4];
                System.arraycopy(data,i*5*4+i1*4,d,0,4);
                switch (i1){
                    case 0:
                        int dnameSpace = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("dnameSpace:");
                        showInt(dnameSpace);
                        break;
                    case 1:
                        int dUri = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("Name:");
                        showInt(dUri);
                        break;
                    case 2:
                        int dname = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("valuestar:");
                        showInt(dname);
                        break;
                    case 3:
                        int dvalueString = (HexToInt(bytesToHexString(bytesDisplace(d)))>>24);
                        System.out.print("type:");
                        showInt(dvalueString);
                        break;
                    case 4:
                        int ddata = HexToInt(bytesToHexString(bytesDisplace(d)));
                        System.out.print("data:");
                        showInt(ddata);
                        break;

                }
            }

        }

        System.out.println("***************************************************");

        System.out.println("------------------------------");
//        System.out.print(strings.get(HexToInt(bytesToHexString(Prefix)))+"=");
//        System.out.println(strings.get(HexToInt(bytesToHexString(Uri))));
        if(HexToInt(bytesToHexString(Uri))!=-1){
            System.out.print(strings.get(HexToInt(bytesToHexString(Uri)))+"=");
        }else {
            System.out.print("null"+"=");
        }
        if(HexToInt(bytesToHexString(Name))!=-1){
            System.out.println(strings.get(HexToInt(bytesToHexString(Name))));
        }else {
            System.out.println("null");
        }
        System.out.println("------------StartTagChunk完毕");

    }

    public static void showInt(int i){
        if (i!=-1){
            System.out.println(strings.get(i));
        }else{
            System.out.println("null");

        }
    }
    private static void readStartNamespaceChunk(byte[] bytes) {
        byte[] chunkType=new byte[4]; // 标识不同 chunk 类型
        byte[] chunkSize=new byte[4]; // 该 chunk 字节数
        byte[] lineNumber=new byte[4]; // 行号
        byte[] Unknown=new byte[4];
        byte[] Prefix=new byte[4];
        byte[] Uri=new byte[4];

        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize,chunkType,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+4,chunkSize,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+8,lineNumber,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+12,Unknown,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+16,Prefix,0,4);
        System.arraycopy(bytes,StringChunkOver+ResourceIdChunksize+20,Uri,0,4);

        chunkType=bytesDisplace(chunkType);
        chunkSize=bytesDisplace(chunkSize);
        lineNumber=bytesDisplace(lineNumber);
        Unknown=bytesDisplace(Unknown);
        Prefix=bytesDisplace(Prefix);
        Uri=bytesDisplace(Uri);

        System.out.println("..........Start NamespaceChunk...........");
        System.out.println("chunkType:"+bytesToHexString(chunkType));
        System.out.println("chunkSize:"+HexToInt(bytesToHexString(chunkSize)));
        StartNamespaceChunksize=HexToInt(bytesToHexString(chunkSize));
        System.out.println("lineNumber:"+bytesToHexString(lineNumber));
        System.out.println("Unknown:"+bytesToHexString(Unknown));
        System.out.println("Prefix:"+HexToInt(bytesToHexString(Prefix)));
        System.out.println("Uri:"+HexToInt(bytesToHexString(Uri)));
        System.out.println("------------------------------");
        System.out.print(strings.get(HexToInt(bytesToHexString(Prefix)))+"=");
        System.out.println(strings.get(HexToInt(bytesToHexString(Uri))));
        System.out.println("------------解析readStartNamespaceChunk完毕");
    }

    private static void readResourceIdChunk(byte[] bytes) {
        System.out.println("..........Resource IdChunk...........");
        byte[] ChunkType  =new byte[4];
        byte[] ChunkSize  =new byte[4];

        System.arraycopy(bytes,StringChunkOver,ChunkType,0,4);
        System.arraycopy(bytes,StringChunkOver+4,ChunkSize,0,4);

        System.out.println("ChunkType:\t"+bytesToHexString(bytesDisplace(ChunkType)));

        int ResourceIdsSize=HexToInt(bytesToHexString(bytesDisplace(ChunkSize)));
        System.out.println("ChunkSize:\t"+ResourceIdsSize+"byte大小");
        ResourceIdChunksize=ResourceIdsSize;
        byte[] ResourceIds=new byte[(ResourceIdsSize-8)];
        System.arraycopy(bytes,StringChunkOver+8,ResourceIds,0,(ResourceIdsSize-8));


        for (int i = 0; i < (ResourceIdsSize - 8) / 4; i++) {
            byte[] numberBytes = new byte[4];
            System.arraycopy(ResourceIds,i*4,numberBytes,0,4);
            System.out.println("resource id["+i+"]:"+bytesToHexString(bytesDisplace(numberBytes)));
        }



    }

    public static void readStringChunk(byte[] bytes){
        byte[] ChunkType=new byte[4];
        byte[] ChunkSize=new byte[4];
        byte[] StringCount=new byte[4];
        byte[] StyleCount=new byte[4];
        byte[] Unkown=new byte[4];
        byte[] StringPoolOffset =new byte[4];
        byte[] StylePoolOffset  =new byte[4];
        byte[] StringOffsets=new byte[4];
        byte[] StyleOffets=new byte[4];
        byte[] StringPool=new byte[4];
        byte[] StylePool=new byte[4];


        System.arraycopy(bytes,8,ChunkType,0,4);
        System.arraycopy(bytes,12,ChunkSize,0,4);
        System.arraycopy(bytes,16,StringCount,0,4);
        System.arraycopy(bytes,20,StyleCount,0,4);
        System.arraycopy(bytes,24,Unkown,0,4);
        System.arraycopy(bytes,28,StringPoolOffset,0,4);
        System.arraycopy(bytes,32,StylePoolOffset,0,4);
        System.arraycopy(bytes,36,StringOffsets,0,4);
        System.arraycopy(bytes,40,StyleOffets,0,4);
        System.arraycopy(bytes,44,StringPool,0,4);
        System.arraycopy(bytes,48,StylePool,0,4);

        ChunkType=bytesDisplace(ChunkType);
        ChunkSize=bytesDisplace(ChunkSize);
        StringChunkOver=HexToInt(bytesToHexString(ChunkSize))+8;
        StringCount=bytesDisplace(StringCount);
        StyleCount=bytesDisplace(StyleCount);
        Unkown=bytesDisplace(Unkown);
        StringPoolOffset=bytesDisplace(StringPoolOffset);
        StylePoolOffset=bytesDisplace(StylePoolOffset);
        StringOffsets=bytesDisplace(StringOffsets);
        StyleOffets=bytesDisplace(StyleOffets);
        StringPool=bytesDisplace(StringPool);
        StylePool=bytesDisplace(StylePool);

        System.out.println("..........String Chunk...........");

        System.out.println("chunktype:\t"+bytesToHexString(ChunkType));
        System.out.println("ChunkSize:\t"+HexToInt(bytesToHexString(ChunkSize))+"字节");
        System.out.println("StringCount:\t"+HexToInt(bytesToHexString(StringCount))+"个字符串");
        System.out.println("StyleCount:\t"+HexToInt(bytesToHexString(StyleCount))+"个样式");
        System.out.println("StringPoolOffset:\t"+HexToInt(bytesToHexString(StringPoolOffset)));
        int StringPoolOffsetNumber=HexToInt(bytesToHexString(StringPoolOffset))+8;
        int StringCounts=HexToInt(bytesToHexString(StringCount));
        int nextindex=0;
        for (int i = 0; i < StringCounts; i++) {
            byte[] sizebytes = new byte[2];
            System.arraycopy(bytes,StringPoolOffsetNumber+nextindex,sizebytes,0,2);
            sizebytes=bytesDisplace(sizebytes);
           // System.out.println(Arrays.toString(sizebytes));
            int size=HexToInt(bytesToHexString(sizebytes));
            byte[] stringbytes = new byte[size*2];
            System.arraycopy(bytes,StringPoolOffsetNumber+nextindex+2,stringbytes,0,size*2);
            nextindex=nextindex+2+size*2+2;
            String s=null;
            //System.out.println(Arrays.toString(stringbytes));
            try {
                s= new String(getStr(stringbytes));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            strings.add(s);
        }


        System.out.println("StylePoolOffset:\t"+HexToInt(bytesToHexString(StylePoolOffset)));
        System.out.println("StringOffsets:\t"+HexToInt(bytesToHexString(StringOffsets)));
        System.out.println("StyleOffets:\t"+HexToInt(bytesToHexString(StyleOffets)));
        System.out.println("StringPool:\t"+HexToInt(bytesToHexString(StringPool)));
        System.out.println(strings);
        //System.out.println(new String(bytes1));

    }
    public static byte[] getStr(byte[] bytes){
        byte[] b = new byte[bytes.length / 2];

        for (int i = 0; i < bytes.length/2; i++) {
            b[i]=bytes[2*i];
        }
        return b;
    }

    public static void readXmlHeader(byte[] bytes){
        System.arraycopy(bytes,0,XMLHEADER,0,8);
        byte[] magic = new byte[4];
        byte[] fileSize = new byte[4];
        System.arraycopy(bytes,0,magic,0,4);
        System.arraycopy(bytes,4,fileSize,0,4);
        magic=bytesDisplace(magic);
        fileSize=bytesDisplace(fileSize);
        System.out.println("..........Header...........");
        System.out.println("magic:\t"+bytesToHexString(magic));
        System.out.println("size:\t"+HexToInt(bytesToHexString(fileSize))+"字节");
    }

    public static byte[] bytesDisplace(byte[] bytes){
        for (int i = 0; i < bytes.length/2; i++) {
            byte tmp=bytes[i];
            bytes[i]=bytes[bytes.length-1-i];
            bytes[bytes.length-1-i]=tmp;
        }
        return bytes;
    }

    public static int HexToInt(String s){
//        if(s.length()>0){
//            s="0x"+s;
//        }
        //BigInteger bigInteger = new BigInteger(s, 16);
        int decode =(int)Long.parseLong(s, 16); //Integer.decode(s);
        return decode;
    }

    /*
    作用：将byte 以十六进制 显示
     */
    public static String bytesToHexString(byte[] bytes){
        String HEX=null;
        StringBuffer sb = new StringBuffer();
        if(!(bytes ==null)){
            for (byte aByte : bytes) {
                int num=aByte&0xff;
                String s = Integer.toHexString(num);
                if (s.length()<2){
                    s="0"+s;
                }
                sb.append(s);
            }
        }
        return sb.toString();
    }


/*
time:2023/3/18
path:传入要解析的路径
返回：所读取的bytes
 */
    static byte[] readXml(String path){
        byte[] bytes =null;
        File file = new File(path);
        ByteArrayOutputStream bos=null;
        FileInputStream fis=null;


        if (!file.exists()){
            Log.d(TAG, "readXml: 文件不存在！");
        }
        try{
            fis = new FileInputStream(file);
            bos= new ByteArrayOutputStream();

            int len=0;
            byte[] bys = new byte[1024];
            while((len=fis.read(bys))!=-1){
                bos.write(bys,0,len);
            }

            bytes = bos.toByteArray();
        }catch (Exception e){

        }
        return bytes;
    }
}
