#include <stdio.h>

#include <elf.h>

Elf32_Ehdr ELFheader;

Elf32_Shdr *ELF_Shdr;   //section
Elf32_Phdr *ELF_Phdr;
 FILE *fp;

 char *string_pools;

 //�ַ��������س�ʼ���� �������������ַ�����ַ
 char* getStringIndex(int index){
     return ( char *)((int)string_pools + index+0);
 }

 //��ʾELF ͷ��
 void show_ELFheader(){
//     unsigned char e_ident[16];
//     Elf32_Half e_type;
//     Elf32_Half e_machine;
//     Elf32_Word e_version;
//     Elf32_Addr e_entry;
//     Elf32_Off e_phoff;
//     Elf32_Off e_shoff;
//     Elf32_Word e_flags;
//     Elf32_Half e_ehsize;
//     Elf32_Half e_phentsize;
//     Elf32_Half e_phnum;
//     Elf32_Half e_shentsize;
//     Elf32_Half e_shnum;
//     Elf32_Half e_shstrndx;
     printf("ͷ������ʾ��\n");
        printf("e_ident:\t\t %s\n",ELFheader.e_ident);
        printf("e_type:\t\t\t %d\n",ELFheader.e_type);
        printf("e_machine:\t\t %d\n",ELFheader.e_machine);
        printf("e_version:\t\t %d\n",ELFheader.e_version);
        printf("e_entry:\t\t %d\n",ELFheader.e_entry);
         printf("e_phoff:\t\t %d\n",ELFheader.e_phoff);
        printf("e_shoff:\t\t %d\n",ELFheader.e_shoff);
        printf("e_flags:\t\t %d\n",ELFheader.e_flags);
        printf("e_ehsize:\t\t %d\n",ELFheader.e_ehsize);
        printf("e_phentsize:\t\t %d\n",ELFheader.e_phentsize);
        printf("e_phnum:\t\t %d\n",ELFheader.e_phnum);
        printf("e_shentsize:\t\t %d\n",ELFheader.e_shentsize);
        printf("e_shnum:\t\t %d\n",ELFheader.e_shnum);
        printf("e_shstrndx:\t\t %d\n",ELFheader.e_shstrndx);
        printf("ͷ������ʾ����...\n");
 }

 //�ַ��������س�ʼ��
 void init_string_pools(){

     //����seek
     fseek(fp,ELFheader.e_shoff,0);

     fread((void *)ELF_Shdr,sizeof (Elf32_Shdr),ELFheader.e_shnum,fp);

    // printf("string pools : %X  ����ֵ:4112D ",ELF_Shdr[ELFheader.e_shstrndx].sh_offset);

     string_pools=(void *)malloc(ELF_Shdr[ELFheader.e_shstrndx].sh_size);

    // printf("�ַ�����ַ�� %X  �� ��СΪ%d���ֽ�\n",ELF_Shdr[ELFheader.e_shstrndx].sh_offset,ELF_Shdr[ELFheader.e_shstrndx].sh_size);

     fseek(fp,ELF_Shdr[ELFheader.e_shstrndx].sh_offset,0);
     fread(string_pools,sizeof (char),ELF_Shdr[ELFheader.e_shstrndx].sh_size,fp);

     //��������ɶ��ַ��������صĽ��� ������Ҫʹ�õ�ֱ��д��������ȡ��ַ��

     //���� getStringIndex

    // printf("���� �ַ��� ��%s  ����ֵ��.shstrtab",getStringIndex(222));

 }


 void show_ELF_Shdrs(){

     printf("����ȫ����ʾ��\n");
    printf("\n%20s \t %10s \t %6s \t %6s \t %6s %5s %5s %5s %5s %5s","name","type","addr","off","size","ES","Flg","Lk","Inf","Al");
     for(int i=1;i<ELFheader.e_shnum;i++){
         printf("\n%20s \t %10x \t %6x \t %6x \t %6d %5d %5d %5d %5d %5d",getStringIndex(ELF_Shdr[i].sh_name),ELF_Shdr[i].sh_type,ELF_Shdr[i].sh_addr,ELF_Shdr[i].sh_offset,ELF_Shdr[i].sh_size,ELF_Shdr[i].sh_entsize,ELF_Shdr[i].sh_flags,ELF_Shdr[i].sh_link,ELF_Shdr[i].sh_info,ELF_Shdr[i].sh_addralign);
     }
       printf("\n������ʾ����....\n");
 }

char * dynstr;

char * getDynstrIndex(int index){
   return ( char *)((int)dynstr + index+0);
}
 void  show_ELF_Phdrs(){

     //����seek
     fseek(fp,ELFheader.e_phoff,0);

     fread((void *)ELF_Phdr,sizeof (char),sizeof (Elf32_Phdr)*ELFheader.e_phnum,fp);



     printf("\n%8s \t %8s \t %8s \t %8s \t %8s \t %8s \t %5s \t %5s \t", "Type", "Offset", "VirtAddr", "PhysAddr", "FileSiz", "MemSiz", "Flg", "Align");



     for(int i=0;i<ELFheader.e_phnum;i++){
         printf("\n%8x \t %-8.8x \t %-8.8x \t %-8.8x \t %8.8x \t %8.8x \t %5x \t %5x \t",ELF_Phdr[i].p_type,ELF_Phdr[i].p_offset,ELF_Phdr[i].p_vaddr,ELF_Phdr[i].p_paddr,ELF_Phdr[i].p_filesz,ELF_Phdr[i].p_memsz,ELF_Phdr[i].p_flags,ELF_Phdr[i].p_align);
     }
 }

 //��ʼ�����ű����ַ���
 void init_dynstr(){
     for(int i=0;i<ELFheader.e_shnum;i++){
        //  printf("sh_offset %x sh_size %x  --> %s",ELF_Shdr[i].sh_offset,ELF_Shdr[i].sh_size);


         if(strcmp(".dynstr",getStringIndex(ELF_Shdr[i].sh_name))==0){
             printf("\n�ҵ��� dynstr������ %d\n",i);
//             ELF_Shdr[i].sh_offset;
//             ELF_Shdr[i].sh_size;
            // printf("sh_offset %x sh_size %x  ",(int)ELF_Shdr[i].sh_offset,(int)ELF_Shdr[i].sh_size);

             dynstr=(char *)malloc(ELF_Shdr[i].sh_size);
             fseek(fp,ELF_Shdr[i].sh_offset,0);
             fread(dynstr,sizeof(char), ELF_Shdr[i].sh_size,fp);

             //printf("\n%x\n",(int)dynstr);
         }

     }
 }
Elf32_Sym * dynsym;   //���ű�
 void show_dynsym(){

    int num;

     //2.����.dynsym
     for(int i=0;i<ELFheader.e_shnum;i++){
         if(strcmp(".dynsym",getStringIndex(ELF_Shdr[i].sh_name))==0){
             printf("\n�ҵ��� .dynsym������ index:%d\n",i);
//             ELF_Shdr[i].sh_offset;
//             ELF_Shdr[i].sh_size;
            // printf("sh_offset %x sh_size %x  ",(int)ELF_Shdr[i].sh_offset,(int)ELF_Shdr[i].sh_size);

             dynsym=(char *)malloc(sizeof(Elf32_Sym) * (int)ELF_Shdr[i].sh_size);
             fseek(fp,ELF_Shdr[i].sh_offset,0);
             fread(dynsym,sizeof(Elf32_Sym), ELF_Shdr[i].sh_size,fp);

             num=ELF_Shdr[i].sh_size;

            // printf("\n%x\n",(int)dynsym);
         }

     }
 printf("\n%5s  %8s %4s %4s %4s %4s  name\n","index","address","size","info","other","shndx");

//     for(int i=0;i<num;i++){
//         printf("%5d  %8x %4x %4x %4x %4x  ",i,dynsym[i].st_value,dynsym[i].st_size,dynsym[i].st_info,dynsym[i].st_other,dynsym[i].st_shndx);
//         printf("%s \n",getDynstrIndex(dynsym[i].st_name));
//     }

 }

void show_rel(){

    //.rel.dyn .rel.plt

   Elf32_Rel * reldyn, * relplt;
   int reldynLen,relpltLen;
    printf("�ض�λ��\n");
   for(int i=0;i<ELFheader.e_shnum;i++){
      //  printf("sh_offset %x sh_size %x  --> %s",ELF_Shdr[i].sh_offset,ELF_Shdr[i].sh_size);
       if(strcmp(".rel.dyn",getStringIndex(ELF_Shdr[i].sh_name))==0){
           printf("\n�ҵ��� .rel.dyn %d\n",i);
//             ELF_Shdr[i].sh_offset;
//             ELF_Shdr[i].sh_size;
           printf("sh_offset %x sh_size %x  ",(int)ELF_Shdr[i].sh_offset,(int)ELF_Shdr[i].sh_size);
           reldyn=(void *)malloc(sizeof(Elf32_Rel)*ELF_Shdr[i].sh_size);

           reldynLen=ELF_Shdr[i].sh_size;
           fseek(fp,ELF_Shdr[i].sh_offset,0);
           fread(reldyn,sizeof(Elf32_Rel), ELF_Shdr[i].sh_size,fp);

           //printf("\n%x\n",(int)dynstr);
       }

   }
   for(int i=0;i<ELFheader.e_shnum;i++){
      //  printf("sh_offset %x sh_size %x  --> %s",ELF_Shdr[i].sh_offset,ELF_Shdr[i].sh_size);
       if(strcmp(".rel.plt",getStringIndex(ELF_Shdr[i].sh_name))==0){
           printf("\n�ҵ��� .rel.plt %d\n",i);
//             ELF_Shdr[i].sh_offset;
//             ELF_Shdr[i].sh_size;
           printf("sh_offset %x sh_size %x  ",(int)ELF_Shdr[i].sh_offset,(int)ELF_Shdr[i].sh_size);
           relplt=(void *)malloc(sizeof(Elf32_Rel)*ELF_Shdr[i].sh_size);
           relpltLen=ELF_Shdr[i].sh_size;
           fseek(fp,ELF_Shdr[i].sh_offset,0);
           fread(relplt,sizeof(Elf32_Rel), ELF_Shdr[i].sh_size,fp);

           //printf("\n%x\n",(int)dynstr);
       }

   }


//   for(int i=0;i<reldynLen;i++){

//       int Type =reldyn[i].r_info & 0xff;
//       int index = (reldyn[i].r_info & 0xfff00)>>8;
//       printf("%x \n %x %x",reldyn[i].r_offset,Type,index);
//   }

      for(int i=0;i<relpltLen;i++){

          int Type =relplt[i].r_info & 0xff;
          int index = (relplt[i].r_info & 0xfff00)>>8;
          printf("%8x\t%5x\t%5x %s\n",relplt[i].r_offset,Type,index,getDynstrIndex(dynsym[index].st_name));
      }



}

//��ʼ��ȫ��
 void init(){
    fread((void *)&ELFheader,sizeof (Elf32_Ehdr),1,fp);
   show_ELFheader();

   //��ȡ���������С
   ELF_Shdr = (void *)malloc(sizeof (Elf32_Shdr)*ELFheader.e_shnum);
   ELF_Phdr = (void *)malloc(sizeof (Elf32_Shdr)*ELFheader.e_phnum);
   //�����ַ�����
   init_string_pools();

   //��ʾ����
    show_ELF_Shdrs();

    //��ʾ����
    show_ELF_Phdrs();

    //1.���������ַ�����
    init_dynstr();

    //�������ű�.dynsym
    show_dynsym();

    //�ض�λ������
    show_rel();
}

int main()
{

    //system("mode con: cols=200 lines=100");
    fp = fopen("C:\\Users\\Administrator\\Desktop\\so�ļ�����\\libsotest.so","r");

    if(fp == NULL){
        perror("���ļ�ʧ�ܣ�");
    }else{
        printf("open ELF file success! loading ......\n");
        init();


    }

    return 0;
}
